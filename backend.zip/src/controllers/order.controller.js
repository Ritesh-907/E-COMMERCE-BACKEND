/**
 * controllers/order.controller.js — Order Management
 * =====================================================
 * PURPOSE: Create orders, manage lifecycle, admin order management.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  createOrder(req, res)
 *    - Validate request: items array, shippingAddress, paymentMethod
 *    - For each item: fetch product, verify isPublished, check stock
 *    - Collect out-of-stock items → if any, AppError(400, 'Items out of stock: ...')
 *    - Apply coupon if req.body.couponCode:
 *        couponService.validateAndApplyCoupon(code, userId, total)
 *    - Calculate totals: orderService.calculateOrderTotals(items, coupon, address)
 *    - Wrap in Mongoose session + transaction:
 *        await orderService.decrementStock(items, session)
 *        await Cart.findOneAndDelete({ user: req.user.id }, { session })
 *        const order = await Order.create([orderData], { session })
 *        if (coupon): await couponService.markCouponUsed(couponId, userId)
 *    - Emit 'order.created' event: orderEmitter.emit('order.created', { order, user })
 *    - Return 201 with created order
 *
 *  getUserOrders(req, res)
 *    - Order.find({ user: req.user.id }).sort('-createdAt')
 *    - Paginate with getPaginationParams(req.query)
 *    - Populate items.product (name, images)
 *    - Return 200 with orders + pagination
 *
 *  getOrderById(req, res)
 *    - Order.findById(params.id).populate('user', 'name email').populate('items.product', 'name images slug')
 *    - If not found → AppError(404)
 *    - If req.user.role !== 'admin' AND order.user._id !== req.user.id → AppError(403)
 *    - Return 200 with order
 *
 *  cancelOrder(req, res)
 *    - Find order (with ownership check)
 *    - If status not in ['pending','processing'] → AppError(400, 'Order cannot be cancelled')
 *    - orderService.restoreStock(order.items)
 *    - If order.isPaid: trigger refund via paymentService.refundPayment(order.paymentResult.id)
 *    - Set order.orderStatus = 'cancelled', order.cancelReason = req.body.reason
 *    - Save, emit 'order.cancelled' event
 *    - Return 200 with updated order
 *
 *  --- Admin Only ---
 *
 *  getAllOrders(req, res)
 *    - APIFeatures on Order model: filter by status, date range, paymentMethod
 *    - Populate user (name, email)
 *    - Paginate
 *    - Return 200 with orders + stats (total revenue, count by status)
 *
 *  updateOrderStatus(req, res)
 *    - Validate new status is a valid progression (e.g. can't go from delivered → pending)
 *    - Update order.orderStatus, set timestamps (paidAt, deliveredAt) as appropriate
 *    - Emit 'order.statusUpdated' event
 *    - Return 200 with updated order
 *
 *  addTrackingNumber(req, res)
 *    - Add order.trackingNumber = req.body.trackingNumber
 *    - Optionally auto-update status to 'shipped'
 *    - Return 200 with updated order
 *
 * TIPS:
 *  - Use Mongoose sessions for createOrder to ensure atomicity
 *  - Never trust req.body prices — always fetch from DB
 *  - Send order confirmation email via event listener (not directly in controller)
 */
