/**
 * controllers/product.controller.js — Product CRUD & Catalog
 * =============================================================
 * PURPOSE: Public catalog browsing and admin/seller product management.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getAllProducts(req, res)
 *    - Build query using APIFeatures(Product.find({ isPublished: true }), req.query)
 *      .filter()    → supports: category, price[gte/lte], brand, ratings[gte], tags
 *      .search()    → req.query.search → $text search on name/description
 *      .sort()      → default '-createdAt', support: price, -price, ratings.average
 *      .limitFields()
 *      .paginate()
 *    - Run countDocuments for pagination meta
 *    - Populate: category (name, slug)
 *    - Return 200: { success: true, data: { products, pagination } }
 *
 *  getProductById(req, res)
 *    - Find by params.id (validate ObjectId first) or params.slug
 *    - Populate: category (name, slug), seller (name, avatar)
 *    - Also fetch 3 most recent reviews for preview
 *    - Increment view count (optional): Product.findByIdAndUpdate(id, { $inc: { views: 1 } })
 *    - Return 200 with full product + reviews preview
 *
 *  createProduct(req, res)
 *    - Validate with product.validator.js via validate middleware (already done by route)
 *    - If req.files exist: uploadService.uploadMultipleImages(files, 'ecommerce/products')
 *    - Set seller = req.user._id
 *    - Product.create({ ...body, images, seller })
 *    - Invalidate product cache: cacheService.flush('cache:/api/v1/products*')
 *    - Emit 'product.created' event
 *    - Return 201 with created product
 *
 *  updateProduct(req, res)
 *    - Use req.resource (set by checkOwnership middleware) to avoid re-fetching
 *    - Handle image updates:
 *        NEW images in req.files → upload to Cloudinary → add to images array
 *        REMOVED images in req.body.removeImages (array of public_ids) → delete from Cloudinary + remove from array
 *    - Update other fields: Object.assign(product, allowedUpdates)
 *    - Save product (triggers slug regeneration if name changed)
 *    - Invalidate cache
 *    - Return 200 with updated product
 *
 *  deleteProduct(req, res)
 *    - Delete all product images from Cloudinary
 *    - Delete all reviews for this product: Review.deleteMany({ product: id })
 *    - Product.findByIdAndDelete(id)
 *    - Invalidate cache
 *    - Return 200: { success: true, message: 'Product deleted.' }
 *
 *  getFeaturedProducts(req, res)
 *    - Product.find({ isFeatured: true, isPublished: true }).limit(10)
 *    - Cache for 1 hour
 *    - Return 200 with products array
 *
 *  getRelatedProducts(req, res)
 *    - Find product to get its category
 *    - Product.find({ category: product.category, _id: { $ne: id }, isPublished: true }).limit(6)
 *    - Return 200 with related products
 *
 * TIPS:
 *  - For text search: use $text: { $search: req.query.search } in filter
 *  - Always check isPublished: true for public endpoints
 *  - Use .lean() on list queries for 2-3x performance improvement
 *  - Validate ObjectId before DB query: mongoose.isValidObjectId(id)
 */
