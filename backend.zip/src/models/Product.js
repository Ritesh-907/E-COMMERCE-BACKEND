/**
 * models/Product.js — Product Schema & Model
 * =============================================
 * PURPOSE: Define the Product MongoDB schema with full catalog features.
 *
 * FIELDS TO INCLUDE:
 *  - name         : String, required, trim
 *  - slug         : String, unique, lowercase (auto-generated)
 *  - description  : String, required
 *  - shortDesc    : String, maxLength 200
 *  - price        : Number, required, min 0
 *  - comparePrice : Number, min 0 (original price for discount display)
 *  - category     : ObjectId ref 'Category', required
 *  - seller       : ObjectId ref 'User'
 *  - images       : [{ url: String, public_id: String }]
 *  - stock        : Number, default 0, min 0
 *  - sold         : Number, default 0
 *  - sku          : String, unique, sparse
 *  - brand        : String
 *  - ratings      : { average: Number default 0, count: Number default 0 }
 *  - attributes   : Map of Mixed (for size, color, weight, etc.)
 *  - tags         : [String]
 *  - isFeatured   : Boolean, default false
 *  - isPublished  : Boolean, default false
 *  - timestamps   : true
 *
 * HOOKS & VIRTUALS TO IMPLEMENT:
 *  - pre('save'): if name modified → generate slug using slugify(name, { lower: true })
 *  - virtual 'discountPercent':
 *      if (this.comparePrice && this.comparePrice > this.price)
 *        return Math.round(((this.comparePrice - this.price) / this.comparePrice) * 100)
 *      return 0
 *  - virtual 'inStock': return this.stock > 0
 *
 * INDEXES TO ADD:
 *  - Text index: { name: 'text', description: 'text', brand: 'text' } for search
 *  - Compound: { category: 1, isPublished: 1 } for catalog queries
 *  - { isFeatured: 1, isPublished: 1 } for featured section
 *
 * TIPS:
 *  - Use .lean() for read-only list endpoints (faster, no Mongoose overhead)
 *  - Snapshot name + price into orders at purchase time (prices change)
 *  - Auto-set isPublished = false when stock hits 0 (optional — use events)
 */
