/**
 * utils/constants.js — Application-Wide Constants
 * ==================================================
 * PURPOSE: Single source of truth for all magic numbers and config values.
 *
 * EXPORT THE FOLLOWING:
 *
 *  // Pricing
 *  TAX_RATE                 = 0.1          // 10% tax
 *  FREE_SHIPPING_THRESHOLD  = 500          // Free shipping above $500
 *  SHIPPING_COST            = 10           // Flat rate shipping fee
 *
 *  // Cart
 *  MAX_CART_ITEMS           = 50
 *  MAX_WISHLIST_ITEMS       = 100
 *
 *  // Products
 *  MAX_PRODUCT_IMAGES       = 5
 *  LOW_STOCK_THRESHOLD      = 5            // Alert when stock <= this
 *
 *  // Pagination
 *  DEFAULT_PAGE_SIZE        = 20
 *  MAX_PAGE_SIZE            = 100
 *
 *  // Token expiry (milliseconds)
 *  PASSWORD_RESET_EXPIRE    = 10 * 60 * 1000        // 10 minutes
 *  EMAIL_VERIFY_EXPIRE      = 24 * 60 * 60 * 1000   // 24 hours
 *
 *  // Redis cache TTL (seconds)
 *  CACHE_TTL = {
 *    PRODUCTS:    300,    // 5 minutes
 *    CATEGORIES:  3600,   // 1 hour
 *    FEATURED:    3600,
 *    ANALYTICS:   300,
 *    USER_SESSION: 900    // 15 minutes
 *  }
 *
 *  // Reviews
 *  MAX_REVIEW_IMAGES = 3
 *
 * TIPS:
 *  - Import constants instead of hardcoding values in controllers/services
 *  - Values that might differ per environment: use process.env with fallback
 *    e.g. const TAX_RATE = parseFloat(process.env.TAX_RATE) || 0.1
 */
