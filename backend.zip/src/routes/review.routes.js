/**
 * routes/review.routes.js — Review Routes
 * ==========================================
 * PURPOSE: Product review CRUD. Supports both standalone and nested routing.
 *
 * USAGE PATTERN:
 *  This router is mounted at BOTH:
 *    1. /reviews                             ← standalone (for admin)
 *    2. /products/:productId/reviews         ← nested under products
 *  Use { mergeParams: true } on this router.
 *
 * ROUTES:
 *  GET    /                     → getProductReviews           (public)
 *  POST   /                     → protect, validate(createReviewSchema), createReview
 *  PATCH  /:id                  → protect, validate(updateReviewSchema), updateReview
 *  DELETE /:id                  → protect, deleteReview
 *  POST   /:id/like             → protect, likeReview
 *
 * TIPS:
 *  - With mergeParams: true, req.params.productId is available from the parent route
 *  - Ownership check for update/delete is done inside the controller
 *  - GET reviews is public (no auth required)
 */
