/**
 * utils/crypto.js — Cryptographic Utility Functions
 * ====================================================
 * PURPOSE: Secure token generation and hashing for auth flows.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  generateToken(bytes = 32)
 *    - return crypto.randomBytes(bytes).toString('hex')
 *    - Use for: email verification token, password reset token
 *    - Returns a random hex string (64 chars for 32 bytes)
 *    - Send the RAW token to the user (in email link)
 *    - Store only the HASH in the database
 *
 *  hashToken(rawToken)
 *    - return crypto.createHash('sha256').update(rawToken).digest('hex')
 *    - Use to hash before DB storage, and to hash again when verifying
 *    - Pattern: send raw → store hash → on verify: hash incoming → compare to stored
 *
 *  generateOTP(length = 6)
 *    - Generate a numeric OTP: Math.floor(100000 + Math.random() * 900000).toString()
 *    - For stronger OTP: use crypto.randomInt(100000, 999999).toString()
 *    - Returns a 6-digit string like '847392'
 *
 *  compareHash(rawValue, hash)
 *    - return hashToken(rawValue) === hash
 *    - Utility for quick comparison
 *
 * TIPS:
 *  - NEVER store raw tokens in the database — always hash first
 *  - crypto.randomBytes is cryptographically secure (unlike Math.random)
 *  - For passwords, use bcryptjs (handled in User model) — NOT these functions
 *  - generateToken + hashToken pattern is used in User.getPasswordResetToken()
 */
