/**
 * models/Notification.js — Notification Schema & Model
 * =======================================================
 * PURPOSE: Store in-app notifications for users.
 *
 * FIELDS TO INCLUDE:
 *  - user      : ObjectId ref 'User', required
 *  - type      : String, enum ['order','promo','system','review','stock'], required
 *  - title     : String, required, maxLength 100
 *  - message   : String, required, maxLength 500
 *  - link      : String (frontend route, e.g. '/orders/ORD-2024-001')
 *  - isRead    : Boolean, default false
 *  - metadata  : Mixed (optional extra data, e.g. { orderId, productId })
 *  - timestamps: true
 *
 * INDEXES:
 *  - { user: 1, isRead: 1 } for unread count queries
 *  - { user: 1, createdAt: -1 } for listing notifications
 *  - TTL index: { createdAt: 1 }, expireAfterSeconds: 2592000 (30 days auto-delete)
 *
 * TIPS:
 *  - After creating a notification, emit via Socket.IO: io.to(userId).emit('notification:new', data)
 *  - Keep notifications lightweight — no large embedded data
 *  - Add a static Notification.getUnreadCount(userId) → countDocuments({ user, isRead: false })
 */
