/**
 * scripts/resetDatabase.js — Full Database Reset
 * =================================================
 * PURPOSE: Drop all collections in development/test environments. DESTRUCTIVE.
 *
 * INSTRUCTIONS:
 *  1. Load env: require('dotenv').config()
 *  2. SAFETY CHECK — refuse production:
 *       if (process.env.NODE_ENV === 'production') {
 *         console.error('❌ Cannot reset database in production!')
 *         process.exit(1)
 *       }
 *  3. Prompt for confirmation (interactive safety):
 *       const readline = require('readline')
 *       // Ask: 'Are you sure? Type "yes" to confirm: '
 *       // If not 'yes' → abort
 *  4. Connect to MongoDB
 *  5. Drop all collections:
 *       const collections = ['users', 'products', 'categories', 'orders',
 *                            'carts', 'reviews', 'coupons', 'wishlists',
 *                            'notifications', 'refreshtokens']
 *       for (const name of collections) {
 *         await mongoose.connection.dropCollection(name).catch(() => {})  // Ignore if doesn't exist
 *       }
 *       // OR: await mongoose.connection.dropDatabase()  (drops entire DB)
 *  6. Optionally re-seed: require('./seed')
 *  7. Log: console.log('✅ Database reset complete')
 *  8. process.exit(0)
 *
 * USAGE:
 *  npm run reset-db            → resets with confirmation prompt
 *  NODE_ENV=test npm run reset-db   → for CI/test pipelines
 *
 * TIPS:
 *  !! ALWAYS check NODE_ENV !== 'production' as the FIRST line !!
 *  - Use readline for interactive confirmation in development
 *  - Skip confirmation prompt in test environment (for CI pipelines)
 *  - After reset, optionally run seed automatically
 */
