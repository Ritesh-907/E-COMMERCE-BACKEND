/**
 * config/cors.js — CORS Configuration
 * ======================================
 * PURPOSE: Define which origins can access the API.
 *
 * INSTRUCTIONS:
 *  1. Define allowed origins array:
 *       const allowedOrigins = [
 *         process.env.CLIENT_URL,
 *         'http://localhost:3000',
 *         'http://localhost:5173',  // Vite dev server
 *       ]
 *  2. Export corsOptions:
 *       {
 *         origin: (origin, callback) => {
 *           // Allow requests with no origin (mobile apps, curl, Postman)
 *           if (!origin) return callback(null, true)
 *           if (allowedOrigins.includes(origin)) return callback(null, true)
 *           callback(new Error('Not allowed by CORS'))
 *         },
 *         methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
 *         allowedHeaders: ['Content-Type', 'Authorization'],
 *         credentials: true,           // Allow cookies
 *         optionsSuccessStatus: 200
 *       }
 *
 * TIPS:
 *  - credentials: true is required for httpOnly cookies to work cross-origin
 *  - In production, remove localhost from allowedOrigins
 *  - Log rejected origins in development for easier debugging
 */
