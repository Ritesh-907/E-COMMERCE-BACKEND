/**
 * routes/coupon.routes.js — Coupon Routes
 * ==========================================
 * PURPOSE: Admin coupon CRUD + user coupon validation.
 *
 * ROUTES:
 *  POST   /validate             → protect, validate(validateCouponSchema), validateCoupon
 *
 *  Admin only (protect + authorize('admin')):
 *  GET    /                     → getAllCoupons
 *  GET    /stats                → getCouponStats
 *  GET    /:id                  → getCouponById
 *  POST   /                     → validate(createCouponSchema), createCoupon
 *  PATCH  /:id                  → validate(updateCouponSchema), updateCoupon
 *  DELETE /:id                  → deleteCoupon
 *
 * TIPS:
 *  - /validate is accessible to any authenticated user (not admin-only)
 *  - /stats must be defined before /:id to avoid route conflict
 *  - Never expose full coupon list to non-admins
 */
