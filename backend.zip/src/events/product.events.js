/**
 * events/product.events.js — Product Domain Event Emitter
 * ==========================================================
 * PURPOSE: Handle side-effects of product state changes.
 *
 * INSTRUCTIONS:
 *  1. Create productEmitter = new EventEmitter()
 *  2. Register listeners:
 *
 *  productEmitter.on('product.created', async ({ product, seller }) => {
 *    try {
 *      await invalidateCache('cache:/api/v1/products*')  // Bust product list cache
 *      logger.info('Product created', { productId: product._id, sellerId: seller?._id })
 *    } catch (err) { logger.error('product.created handler failed', { err }) }
 *  })
 *
 *  productEmitter.on('product.outOfStock', async ({ product }) => {
 *    try {
 *      // Notify admin via notification
 *      const admins = await User.find({ role: 'admin', isActive: true })
 *      for (const admin of admins) {
 *        await notificationService.createNotification({
 *          userId: admin._id, type: NOTIFICATION_TYPE.STOCK,
 *          title: 'Product Out of Stock',
 *          message: `"${product.name}" is now out of stock.`,
 *          link: `/admin/products/${product._id}`
 *        })
 *      }
 *    } catch (err) { logger.error('product.outOfStock handler failed', { err }) }
 *  })
 *
 *  productEmitter.on('product.backInStock', async ({ product }) => {
 *    try {
 *      // Find users who wishlisted this product
 *      const wishlists = await Wishlist.find({ products: product._id }).populate('user', 'email name')
 *      for (const wishlist of wishlists) {
 *        await notificationService.createNotification({
 *          userId: wishlist.user._id, type: NOTIFICATION_TYPE.STOCK,
 *          title: 'Back in Stock!',
 *          message: `"${product.name}" you saved is back in stock.`,
 *          link: `/products/${product.slug}`
 *        })
 *      }
 *    } catch (err) { logger.error('product.backInStock handler failed', { err }) }
 *  })
 *
 *  productEmitter.on('product.priceDropped', async ({ product, oldPrice }) => {
 *    try {
 *      // Same pattern as backInStock — notify wishlist users
 *    } catch (err) { logger.error('product.priceDropped handler failed', { err }) }
 *  })
 *
 *  3. module.exports = productEmitter
 *
 * TIPS:
 *  - Emit product.outOfStock in order.service.js after decrementStock when stock hits 0
 *  - Emit product.backInStock in product.controller.js updateProduct when stock > 0 (was 0)
 *  - Always wrap listeners in try/catch
 */
