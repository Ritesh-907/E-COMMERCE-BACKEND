'use strict';

/**
 * scripts/seed.js — Database Seeder
 * ====================================
 * Populates the database with realistic sample data for development/testing.
 *
 * USAGE:
 *   npm run seed                    → clear + seed
 *   node scripts/seed.js --destroy  → only clear, don't re-seed
 */

require('dotenv').config();
const mongoose = require('mongoose');

// ── Models ────────────────────────────────────────────────────────────────────
const User     = require('../src/models/User');
const Product  = require('../src/models/Product');
const Category = require('../src/models/Category');
const Coupon   = require('../src/models/Coupon');
const Order    = require('../src/models/Order');
const Cart     = require('../src/models/Cart');
const Review   = require('../src/models/Review');

// ── Flags ─────────────────────────────────────────────────────────────────────
const DESTROY_ONLY = process.argv.includes('--destroy');

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Pick a random element from an array */
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

/** Return a random integer between min and max (inclusive) */
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

/** Return a random float rounded to 2 decimal places */
const randPrice = (min, max) => parseFloat((Math.random() * (max - min) + min).toFixed(2));

/** Return a date N days from now */
const daysFromNow = (n) => new Date(Date.now() + n * 24 * 60 * 60 * 1000);

// ── Seed data definitions ─────────────────────────────────────────────────────

const CATEGORY_DATA = [
  { name: 'Electronics',   order: 1 },
  { name: 'Clothing',      order: 2 },
  { name: 'Books',         order: 3 },
  { name: 'Home & Garden', order: 4 },
  { name: 'Sports',        order: 5 },
  { name: 'Beauty',        order: 6 },
];

// Sub-categories are defined after parents are created (see seed function)
const SUB_CATEGORY_DATA = [
  { name: 'Smartphones',  parentKey: 'Electronics', order: 1 },
  { name: 'Laptops',      parentKey: 'Electronics', order: 2 },
  { name: 'Headphones',   parentKey: 'Electronics', order: 3 },
  { name: "Men's Wear",   parentKey: 'Clothing',    order: 1 },
  { name: "Women's Wear", parentKey: 'Clothing',    order: 2 },
];

const USER_DATA = [
  {
    name:       'Admin User',
    email:      'admin@test.com',
    password:   'Admin123!',
    role:       'admin',
    isVerified: true,
    isActive:   true,
    phone:      '+1-555-000-0001',
  },
  {
    name:       'Seller User',
    email:      'seller@test.com',
    password:   'Seller123!',
    role:       'seller',
    isVerified: true,
    isActive:   true,
    phone:      '+1-555-000-0002',
  },
  {
    name:       'Test User',
    email:      'user@test.com',
    password:   'User1234!',
    role:       'user',
    isVerified: true,
    isActive:   true,
    phone:      '+1-555-000-0003',
    addresses: [
      {
        street:    '123 Main St',
        city:      'New York',
        state:     'NY',
        zip:       '10001',
        country:   'USA',
        label:     'Home',
        isDefault: true,
      },
    ],
  },
  {
    name:       'Alice Johnson',
    email:      'alice@test.com',
    password:   'Alice1234!',
    role:       'user',
    isVerified: true,
    isActive:   true,
  },
  {
    name:       'Bob Smith',
    email:      'bob@test.com',
    password:   'Bob12345!',
    role:       'user',
    isVerified: true,
    isActive:   true,
  },
];

// Product templates — category and seller will be injected during seeding
const PRODUCT_TEMPLATES = [
  // Electronics — Smartphones
  {
    name:        'iPhone 15 Pro',
    description: 'Apple iPhone 15 Pro with A17 Pro chip, titanium design, 48MP main camera, and USB-C connectivity. Experience the pinnacle of smartphone technology.',
    shortDesc:   'Apple A17 Pro · 48MP camera · Titanium build',
    price:       999,
    comparePrice:1199,
    brand:       'Apple',
    stock:       50,
    tags:        ['smartphone', 'apple', 'iphone', '5g'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Smartphones',
  },
  {
    name:        'Samsung Galaxy S24 Ultra',
    description: 'Samsung Galaxy S24 Ultra with Snapdragon 8 Gen 3, built-in S Pen, 200MP camera, and a stunning 6.8-inch Dynamic AMOLED display for ultimate productivity.',
    shortDesc:   'Snapdragon 8 Gen 3 · 200MP · S Pen',
    price:       1199,
    comparePrice:1399,
    brand:       'Samsung',
    stock:       35,
    tags:        ['smartphone', 'samsung', 'galaxy', 'android', '5g'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Smartphones',
  },
  {
    name:        'Google Pixel 8',
    description: 'Google Pixel 8 powered by Google Tensor G3 chip. Features the best camera experience with AI-enhanced photography, real-time translation, and seven years of OS updates.',
    shortDesc:   'Tensor G3 · AI camera · 7-year updates',
    price:       699,
    comparePrice:799,
    brand:       'Google',
    stock:       40,
    tags:        ['smartphone', 'google', 'pixel', 'android'],
    isPublished: true,
    categoryKey: 'Smartphones',
  },
  // Electronics — Laptops
  {
    name:        'MacBook Pro 14"',
    description: 'MacBook Pro 14-inch with M3 Pro chip delivers exceptional performance for professionals. Features Liquid Retina XDR display, up to 22 hours battery life, and MagSafe charging.',
    shortDesc:   'M3 Pro chip · Liquid Retina XDR · 22hr battery',
    price:       1999,
    comparePrice:2199,
    brand:       'Apple',
    stock:       20,
    tags:        ['laptop', 'apple', 'macbook', 'pro'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Laptops',
  },
  {
    name:        'Dell XPS 15',
    description: 'Dell XPS 15 with Intel Core i9 13th Gen, NVIDIA GeForce RTX 4060, 32GB RAM, and a stunning 3.5K OLED touchscreen. Perfect for creatives and power users.',
    shortDesc:   'Core i9 · RTX 4060 · 3.5K OLED',
    price:       1799,
    comparePrice:2099,
    brand:       'Dell',
    stock:       15,
    tags:        ['laptop', 'dell', 'xps', 'windows'],
    isPublished: true,
    categoryKey: 'Laptops',
  },
  // Electronics — Headphones
  {
    name:        'Sony WH-1000XM5',
    description: 'Sony WH-1000XM5 wireless headphones offer industry-leading noise cancellation with Auto NC Optimizer, 30-hour battery life, and crystal-clear hands-free calling.',
    shortDesc:   'Industry-leading ANC · 30hr battery · Hi-Res Audio',
    price:       349,
    comparePrice:399,
    brand:       'Sony',
    stock:       60,
    tags:        ['headphones', 'sony', 'wireless', 'noise-cancelling'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Headphones',
  },
  {
    name:        'Apple AirPods Pro (2nd Gen)',
    description: 'AirPods Pro 2nd generation feature Adaptive Audio, Transparency mode, Personalized Spatial Audio with dynamic head tracking, and USB-C charging case.',
    shortDesc:   'Adaptive Audio · Spatial Audio · H2 chip',
    price:       249,
    comparePrice:279,
    brand:       'Apple',
    stock:       80,
    tags:        ['earbuds', 'apple', 'airpods', 'wireless'],
    isPublished: true,
    categoryKey: 'Headphones',
  },
  // Clothing
  {
    name:        'Classic Oxford Shirt',
    description: 'Premium 100% cotton Oxford shirt with a button-down collar. Versatile enough for office wear or casual weekends. Available in multiple colors and sizes.',
    shortDesc:   '100% cotton · Button-down collar · Machine washable',
    price:       59.99,
    comparePrice:79.99,
    brand:       'StyleCo',
    stock:       120,
    tags:        ['shirt', 'cotton', 'mens', 'formal'],
    isPublished: true,
    categoryKey: "Men's Wear",
  },
  {
    name:        'Slim Fit Chinos',
    description: 'Modern slim-fit chinos crafted from stretch twill fabric. These pants offer comfort and style for any occasion from work to weekend outings.',
    shortDesc:   'Stretch twill · Slim fit · Wrinkle-resistant',
    price:       79.99,
    comparePrice:99.99,
    brand:       'StyleCo',
    stock:       90,
    tags:        ['pants', 'chinos', 'mens', 'slim-fit'],
    isPublished: true,
    categoryKey: "Men's Wear",
  },
  {
    name:        'Floral Summer Dress',
    description: 'Lightweight floral print midi dress with adjustable spaghetti straps and an A-line silhouette. Perfect for summer days, beach trips, or casual gatherings.',
    shortDesc:   'Floral print · Midi length · Lightweight',
    price:       49.99,
    comparePrice:69.99,
    brand:       'BloomWear',
    stock:       75,
    tags:        ['dress', 'summer', 'floral', 'womens'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: "Women's Wear",
  },
  // Books
  {
    name:        'Clean Code: A Handbook of Agile Software Craftsmanship',
    description: 'Robert C. Martin\'s landmark book on writing clean, maintainable code. Essential reading for every professional developer looking to improve code quality and team productivity.',
    shortDesc:   'By Robert C. Martin · 464 pages · Paperback',
    price:       39.99,
    comparePrice:49.99,
    brand:       'Prentice Hall',
    stock:       200,
    tags:        ['book', 'programming', 'software', 'coding'],
    isPublished: true,
    categoryKey: 'Books',
  },
  {
    name:        'Atomic Habits',
    description: 'James Clear\'s #1 New York Times bestseller reveals practical strategies for forming good habits, breaking bad ones, and mastering the tiny behaviors that lead to remarkable results.',
    shortDesc:   'By James Clear · 320 pages · Bestseller',
    price:       27.99,
    comparePrice:34.99,
    brand:       'Avery',
    stock:       300,
    tags:        ['book', 'self-help', 'productivity', 'habits'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Books',
  },
  // Home & Garden
  {
    name:        'Nespresso Vertuo Next Coffee Machine',
    description: 'Brew barista-quality coffee at home with the Nespresso Vertuo Next. Centrifusion technology extracts every flavor note from your capsule, delivering five cup sizes from espresso to carafe.',
    shortDesc:   'Centrifusion tech · 5 cup sizes · Fast heat-up',
    price:       179,
    comparePrice:229,
    brand:       'Nespresso',
    stock:       45,
    tags:        ['coffee', 'kitchen', 'appliance', 'nespresso'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Home & Garden',
  },
  {
    name:        'LEGO Architecture Eiffel Tower',
    description: 'Build an iconic replica of Paris\'s Eiffel Tower with this 10,001-piece LEGO set. A challenging and rewarding build for adult LEGO enthusiasts, standing over 59 inches tall when complete.',
    shortDesc:   '10,001 pieces · 59 inches tall · Adult set',
    price:       629.99,
    comparePrice:649.99,
    brand:       'LEGO',
    stock:       18,
    tags:        ['lego', 'collectible', 'home-decor', 'gift'],
    isPublished: true,
    categoryKey: 'Home & Garden',
  },
  // Sports
  {
    name:        'Yoga Mat Pro — 6mm Non-Slip',
    description: 'Professional-grade 6mm thick yoga mat with superior grip and cushioning. Made from eco-friendly TPE material, free of harmful chemicals, and easy to clean after every session.',
    shortDesc:   '6mm thick · Eco TPE · Non-slip surface',
    price:       49.99,
    comparePrice:64.99,
    brand:       'ZenFlow',
    stock:       150,
    tags:        ['yoga', 'fitness', 'mat', 'eco-friendly'],
    isPublished: true,
    categoryKey: 'Sports',
  },
  {
    name:        'Adjustable Dumbbell Set 5–52 lbs',
    description: 'Replace 15 sets of weights with one compact dumbbell. The Bowflex SelectTech 552 adjusts from 5 to 52.5 lbs in 2.5 lb increments using a simple dial mechanism.',
    shortDesc:   '5–52 lbs · 15-in-1 · Space-saving design',
    price:       429,
    comparePrice:499,
    brand:       'Bowflex',
    stock:       25,
    tags:        ['dumbbell', 'weights', 'home-gym', 'fitness'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Sports',
  },
  // Beauty
  {
    name:        'Vitamin C Brightening Serum',
    description: '15% Vitamin C serum with hyaluronic acid and vitamin E. This lightweight formula visibly reduces dark spots, boosts collagen production, and protects against environmental damage.',
    shortDesc:   '15% Vitamin C · Hyaluronic acid · Anti-aging',
    price:       34.99,
    comparePrice:44.99,
    brand:       'GlowLab',
    stock:       200,
    tags:        ['serum', 'vitamin-c', 'skincare', 'brightening'],
    isFeatured:  true,
    isPublished: true,
    categoryKey: 'Beauty',
  },
  {
    name:        'Hydrating Face Moisturizer SPF 30',
    description: 'Daily moisturizer with broad-spectrum SPF 30 protection. Enriched with ceramides and niacinamide to strengthen skin barrier, reduce redness, and maintain all-day hydration.',
    shortDesc:   'SPF 30 · Ceramides · Non-greasy formula',
    price:       24.99,
    comparePrice:29.99,
    brand:       'GlowLab',
    stock:       180,
    tags:        ['moisturizer', 'spf', 'skincare', 'hydrating'],
    isPublished: true,
    categoryKey: 'Beauty',
  },
];

const COUPON_DATA = [
  {
    code:          'WELCOME10',
    type:          'percentage',
    discount:      10,
    maxDiscount:   50,
    minOrderValue: 0,
    usageLimit:    1000,
    expiryDate:    daysFromNow(365),
    isActive:      true,
  },
  {
    code:          'SAVE50',
    type:          'fixed',
    discount:      50,
    minOrderValue: 200,
    usageLimit:    500,
    expiryDate:    daysFromNow(180),
    isActive:      true,
  },
  {
    code:          'FLASH20',
    type:          'percentage',
    discount:      20,
    maxDiscount:   100,
    minOrderValue: 100,
    usageLimit:    200,
    expiryDate:    daysFromNow(30),
    isActive:      true,
  },
  {
    code:          'FREESHIP',
    type:          'fixed',
    discount:      15,
    minOrderValue: 50,
    usageLimit:    null, // unlimited
    expiryDate:    daysFromNow(90),
    isActive:      true,
  },
];

// ── Main seeder ───────────────────────────────────────────────────────────────

async function clearDB() {
  console.log('🗑️  Clearing existing data...');
  await Promise.all([
    User.deleteMany({}),
    Product.deleteMany({}),
    Category.deleteMany({}),
    Order.deleteMany({}),
    Cart.deleteMany({}),
    Review.deleteMany({}),
    Coupon.deleteMany({}),
  ]);
  console.log('✅ All collections cleared.');
}

async function seed() {
  // ── 1. Categories ──────────────────────────────────────────────────────────
  console.log('\n📦 Seeding categories...');

  const parentCategories = await Category.create(CATEGORY_DATA);

  // Build a map: name → _id for easy lookup
  const categoryMap = {};
  parentCategories.forEach((cat) => { categoryMap[cat.name] = cat._id; });

  // Create sub-categories with resolved parent IDs
  const subCategoryDocs = SUB_CATEGORY_DATA.map(({ name, parentKey, order }) => ({
    name,
    order,
    parent: categoryMap[parentKey],
  }));
  const subCategories = await Category.create(subCategoryDocs);
  subCategories.forEach((cat) => { categoryMap[cat.name] = cat._id; });

  console.log(`   ✅ ${parentCategories.length} parent + ${subCategories.length} sub-categories created.`);

  // ── 2. Users ───────────────────────────────────────────────────────────────
  console.log('\n👤 Seeding users...');
  // Use User.create() (not insertMany) so pre-save hooks run (password hashing)
  const users = await User.create(USER_DATA);
  const seller = users.find((u) => u.role === 'seller');
  console.log(`   ✅ ${users.length} users created.`);
  users.forEach((u) => console.log(`      ${u.role.padEnd(6)} → ${u.email}`));

  // ── 3. Products ────────────────────────────────────────────────────────────
  console.log('\n🛍️  Seeding products...');

  const productDocs = PRODUCT_TEMPLATES.map((tpl) => {
    const { categoryKey, ...rest } = tpl;
    const categoryId = categoryMap[categoryKey];

    if (!categoryId) {
      console.warn(`   ⚠️  Category not found for key "${categoryKey}" — skipping product "${tpl.name}"`);
      return null;
    }

    return {
      ...rest,
      category: categoryId,
      seller:   seller._id,
      sku:      `SKU-${tpl.brand.toUpperCase().replace(/\s/g, '')}-${randInt(1000, 9999)}`,
      images: [
        {
          url:       `https://via.placeholder.com/600x600?text=${encodeURIComponent(tpl.name)}`,
          public_id: null,
        },
      ],
    };
  }).filter(Boolean);

  const products = await Product.create(productDocs);
  console.log(`   ✅ ${products.length} products created.`);

  // ── 4. Coupons ─────────────────────────────────────────────────────────────
  console.log('\n🎟️  Seeding coupons...');
  await Coupon.create(COUPON_DATA);
  console.log(`   ✅ ${COUPON_DATA.length} coupons created.`);

  // ── Summary ────────────────────────────────────────────────────────────────
  console.log('\n────────────────────────────────────────');
  console.log('✅ Database seeded successfully!\n');
  console.log('Test credentials:');
  console.log('  Admin  → admin@test.com   / Admin123!');
  console.log('  Seller → seller@test.com  / Seller123!');
  console.log('  User   → user@test.com    / User1234!');
  console.log('────────────────────────────────────────\n');
}

// ── Entry point ───────────────────────────────────────────────────────────────

async function main() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error('❌ MONGO_URI is not defined in .env');
    process.exit(1);
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log('✅ MongoDB connected');

    await clearDB();

    if (!DESTROY_ONLY) {
      await seed();
    } else {
      console.log('\nℹ️  --destroy flag set. Skipping seed.');
    }

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    await mongoose.disconnect().catch(() => {});
    process.exit(1);
  }
}

main();