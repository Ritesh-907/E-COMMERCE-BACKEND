/**
 * models/Cart.js — Cart Schema & Model
 * =======================================
 * PURPOSE: Persist user shopping cart in MongoDB.
 *
 * FIELDS TO INCLUDE:
 *  - user      : ObjectId ref 'User', required, unique (one cart per user)
 *  - items     : [CartItemSchema]
 *  - coupon    : ObjectId ref 'Coupon', default null
 *  - timestamps: true
 *
 * CartItemSchema fields:
 *  - product  : ObjectId ref 'Product', required
 *  - quantity : Number, required, min 1, default 1
 *  - price    : Number (snapshot of price at time of adding)
 *
 * VIRTUALS TO IMPLEMENT:
 *  - totalItems  : items.reduce((sum, item) => sum + item.quantity, 0)
 *  - totalAmount : items.reduce((sum, item) => sum + item.price * item.quantity, 0)
 *
 * TIPS:
 *  - Set { toJSON: { virtuals: true }, toObject: { virtuals: true } } to include virtuals
 *  - Re-validate prices on checkout (don't trust stored price alone)
 *  - Add TTL index: { updatedAt: 1 }, expireAfterSeconds: 2592000 (30 days) for abandoned carts
 *  - On cart population, use .populate({ path: 'items.product', select: 'name images price stock isPublished' })
 */
