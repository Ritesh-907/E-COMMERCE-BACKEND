/**
 * config/aws.js — AWS S3 Configuration
 * =======================================
 * PURPOSE: Configure AWS SDK for S3 file storage (alternative to Cloudinary).
 *
 * INSTRUCTIONS:
 *  1. Import AWS from 'aws-sdk'
 *  2. Configure:
 *       AWS.config.update({
 *         accessKeyId:     process.env.AWS_ACCESS_KEY,
 *         secretAccessKey: process.env.AWS_SECRET_KEY,
 *         region:          process.env.AWS_REGION
 *       })
 *  3. Create and export s3 instance: new AWS.S3()
 *  4. Export helper functions:
 *       uploadToS3(buffer, key, mimetype)
 *         → s3.upload({ Bucket, Key: key, Body: buffer, ContentType: mimetype, ACL: 'public-read' }).promise()
 *         → returns { Location (url), Key }
 *       deleteFromS3(key)
 *         → s3.deleteObject({ Bucket, Key: key }).promise()
 *       getSignedUrl(key, expiresInSeconds = 3600)
 *         → s3.getSignedUrlPromise('getObject', { Bucket, Key, Expires })
 *
 * TIPS:
 *  - Key naming convention: `products/${Date.now()}-${sanitized-filename}`
 *  - Use signed URLs for private documents (invoices, user data)
 *  - ACL: 'public-read' for product images, 'private' for sensitive files
 */
