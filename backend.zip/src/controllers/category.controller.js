/**
 * controllers/category.controller.js — Category Management
 * ===========================================================
 * PURPOSE: CRUD for hierarchical product categories.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getAllCategories(req, res)
 *    - Fetch active categories: Category.find({ isActive: true }).populate('parent', 'name slug').sort('order')
 *    - If req.query.format === 'tree': build nested tree with Category.buildTree()
 *    - Else: return flat array
 *    - Cache result (1 hour TTL): cacheService.remember('categories', 3600, ...)
 *    - Return 200 with categories
 *
 *  getCategoryById(req, res)
 *    - Find by params.id or params.slug
 *    - Populate parent
 *    - Optionally include product count: Product.countDocuments({ category: id, isPublished: true })
 *    - Return 200 with category
 *
 *  createCategory(req, res)  [admin only]
 *    - Validate: name required, parent (optional ObjectId), image (optional file)
 *    - If req.file: upload to Cloudinary folder 'ecommerce/categories'
 *    - Category.create({ name, parent, image, order })
 *    - Bust cache: cacheService.del('categories')
 *    - Return 201 with created category
 *
 *  updateCategory(req, res)  [admin only]
 *    - Find by params.id
 *    - If new image uploaded: upload new, delete old from Cloudinary
 *    - Update fields, save (slug auto-regenerates if name changed)
 *    - Bust cache
 *    - Return 200 with updated category
 *
 *  deleteCategory(req, res)  [admin only]
 *    - Check no products use this category: Product.countDocuments({ category: id }) > 0 → AppError(400)
 *    - Check no child categories: Category.countDocuments({ parent: id }) > 0 → AppError(400)
 *    - Delete category image from Cloudinary if exists
 *    - Category.findByIdAndDelete(id)
 *    - Bust cache
 *    - Return 200: { success: true, message: 'Category deleted.' }
 *
 * TIPS:
 *  - Bust cache on every mutation (create, update, delete)
 *  - For tree building: filter top-level (parent: null), then attach children recursively
 *  - Return product count per category for admin dashboard (use aggregation)
 */
