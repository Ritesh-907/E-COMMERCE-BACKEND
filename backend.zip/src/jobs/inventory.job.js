/**
 * jobs/inventory.job.js — Inventory Monitoring & Alerts
 * ========================================================
 * PURPOSE: Detect low stock and notify admins on a schedule.
 *
 * INSTRUCTIONS:
 *  1. Import cron, Product, User, notificationService, addEmailJob, logger, constants
 *  2. Implement checkLowStock():
 *       a) Find products: { isPublished: true, stock: { $lte: LOW_STOCK_THRESHOLD } }
 *          sorted by stock ascending, limited to 50
 *       b) Separate into:
 *            outOfStock: products where stock === 0
 *            lowStock:   products where stock > 0 && stock <= LOW_STOCK_THRESHOLD
 *       c) If any found:
 *            - Find admin users: User.find({ role: 'admin', isActive: true }).select('email name')
 *            - Send low stock alert email to each admin via addEmailJob
 *            - Create system notification for each admin via notificationService
 *            - Log summary: { outOfStock: N, lowStock: N }
 *
 *  3. Export initInventoryJobs():
 *       cron.schedule('0 9 * * *', checkLowStock)  // Daily at 9 AM
 *       logger.info('Inventory jobs initialized')
 *
 * OPTIONAL ENHANCEMENT:
 *  - Auto-unpublish products where stock === 0 (set isPublished: false)
 *  - Notify wishlist users when a product comes back in stock (product.events.js)
 *
 * TIPS:
 *  - LOW_STOCK_THRESHOLD from utils/constants.js
 *  - Wrap in try/catch — inventory alerts should never crash the server
 *  - Only send alert if there ARE low stock items (avoid empty emails)
 */
