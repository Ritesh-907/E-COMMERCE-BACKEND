/**
 * utils/apiFeatures.js — Mongoose Query Builder
 * ================================================
 * PURPOSE: Chainable class for filtering, searching, sorting, field selection, and pagination.
 *
 * IMPLEMENTATION:
 *
 *  class APIFeatures {
 *    constructor(query, queryString) {
 *      this.query       = query         // Mongoose Query object, e.g. Product.find()
 *      this.queryString = queryString   // req.query object
 *    }
 *
 *    filter() {
 *      const queryObj = { ...this.queryString }
 *      const excludedFields = ['page', 'sort', 'limit', 'fields', 'search']
 *      excludedFields.forEach(f => delete queryObj[f])
 *      // Convert: { price: { gte: 100 } } → { price: { $gte: 100 } }
 *      let queryStr = JSON.stringify(queryObj)
 *      queryStr = queryStr.replace(/\b(gte|gt|lte|lt|ne)\b/g, match => `$${match}`)
 *      this.query = this.query.find(JSON.parse(queryStr))
 *      return this
 *    }
 *
 *    search(searchableFields = ['name']) {
 *      if (this.queryString.search) {
 *        const regex = new RegExp(this.queryString.search, 'i')
 *        const searchConditions = searchableFields.map(f => ({ [f]: regex }))
 *        this.query = this.query.find({ $or: searchConditions })
 *        // OR use $text if text index exists: this.query = this.query.find({ $text: { $search: this.queryString.search } })
 *      }
 *      return this
 *    }
 *
 *    sort() {
 *      const sortBy = this.queryString.sort
 *        ? this.queryString.sort.split(',').join(' ')
 *        : '-createdAt'
 *      this.query = this.query.sort(sortBy)
 *      return this
 *    }
 *
 *    limitFields() {
 *      const fields = this.queryString.fields
 *        ? this.queryString.fields.split(',').join(' ')
 *        : '-__v'
 *      this.query = this.query.select(fields)
 *      return this
 *    }
 *
 *    paginate() {
 *      const page  = Math.max(1, parseInt(this.queryString.page) || 1)
 *      const limit = Math.min(100, parseInt(this.queryString.limit) || 20)
 *      this.query  = this.query.skip((page - 1) * limit).limit(limit)
 *      this.page   = page
 *      this.limit  = limit
 *      return this
 *    }
 *  }
 *
 *  module.exports = APIFeatures
 *
 * USAGE:
 *  const features  = new APIFeatures(Product.find({ isPublished: true }), req.query)
 *    .filter().search(['name','brand']).sort().limitFields().paginate()
 *  const products  = await features.query.lean()
 *  const total     = await Product.countDocuments({ isPublished: true })
 *
 * TIPS:
 *  - Call .lean() at the end for read-only list queries (2-3x faster)
 *  - Run countDocuments BEFORE paginate() for accurate total
 *  - Validate sort fields against a whitelist to prevent arbitrary field access
 */
