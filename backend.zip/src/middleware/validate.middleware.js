/**
 * middleware/validate.middleware.js — Joi Request Validation
 * ============================================================
 * PURPOSE: Validate req.body / req.params / req.query using Joi schemas.
 *
 * EXPORT:
 *  validate(schema, source = 'body') — returns middleware function
 *
 * IMPLEMENTATION:
 *  const validate = (schema, source = 'body') => (req, res, next) => {
 *    const { error, value } = schema.validate(req[source], {
 *      abortEarly: false,      // Return ALL errors at once
 *      allowUnknown: false,    // Reject unknown fields
 *      stripUnknown: true      // Remove unknown fields from value
 *    })
 *    if (error) {
 *      // Map Joi details to clean array: [{ field: 'email', message: 'is required' }]
 *      const errors = error.details.map(d => ({
 *        field: d.path.join('.'),
 *        message: d.message.replace(/['"]/g, '')
 *      }))
 *      return next(new AppError('Validation failed', 422, errors))
 *    }
 *    req[source] = value  // Replace with sanitized/stripped value
 *    next()
 *  }
 *
 *  // AppError needs to accept errors array — update AppError constructor:
 *  // constructor(message, statusCode, errors = null) { ...; this.errors = errors }
 *
 * USAGE:
 *  router.post('/register', validate(registerSchema), authController.register)
 *  router.get('/:id', validate(idParamSchema, 'params'), getById)
 *
 * TIPS:
 *  - Use abortEarly: false so frontend gets ALL field errors at once
 *  - stripUnknown: true prevents mass assignment vulnerabilities
 *  - The replaced req.body value is already sanitized by Joi
 */
