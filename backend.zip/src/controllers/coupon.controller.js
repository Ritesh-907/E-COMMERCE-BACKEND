/**
 * controllers/coupon.controller.js — Coupon Management
 * =======================================================
 * PURPOSE: Admin CRUD for coupons + user coupon validation.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  validateCoupon(req, res)  [authenticated user]
 *    - req.body: { code, orderTotal }
 *    - Call couponService.validateAndApplyCoupon(code, req.user.id, orderTotal)
 *    - If valid: return 200 with { valid: true, discountAmount, coupon: { code, type, discount } }
 *    - If invalid: return 200 with { valid: false, reason } (not a 4xx error)
 *
 *  --- Admin Only ---
 *
 *  getAllCoupons(req, res)
 *    - Paginate + filter by isActive, type
 *    - Return each coupon with: usedCount, remaining uses, expiry status
 *
 *  getCouponById(req, res)
 *    - Find by params.id
 *    - Populate usedBy (user names) for admin insight
 *
 *  createCoupon(req, res)
 *    - Validate via coupon.validator.js (already applied by route middleware)
 *    - Uppercase the code before creating
 *    - Return 201 with created coupon
 *
 *  updateCoupon(req, res)
 *    - Find by params.id, update allowed fields
 *    - If code updated: uppercase it
 *    - Return 200 with updated coupon
 *
 *  deleteCoupon(req, res)
 *    - Find and delete by params.id
 *    - Return 200: { success: true, message: 'Coupon deleted.' }
 *
 *  getCouponStats(req, res)
 *    - Aggregate: total coupons, total discount given, most used coupons
 *    - Return 200 with stats object
 *
 * TIPS:
 *  - validateCoupon returns 200 even if invalid (frontend needs the reason, not an HTTP error)
 *  - usedCount is incremented only at order creation, not validation
 *  - Never expose internal coupon data (usedBy array) to non-admins
 */
