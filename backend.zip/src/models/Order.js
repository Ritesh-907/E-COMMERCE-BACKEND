/**
 * models/Order.js — Order Schema & Model
 * =========================================
 * PURPOSE: Store customer orders with full item snapshot.
 *
 * FIELDS TO INCLUDE:
 *  - orderNumber     : String, unique (auto-generated, e.g. 'ORD-2024-000001')
 *  - user            : ObjectId ref 'User', required
 *  - items           : [OrderItemSchema]
 *  - shippingAddress : { street, city, state, zip, country, phone } (snapshot — not ref)
 *  - paymentMethod   : String, enum ['card','cod','wallet']
 *  - paymentStatus   : String, enum ['pending','paid','failed','refunded'], default 'pending'
 *  - paymentResult   : { id, status, update_time, email_address } (from Stripe/gateway)
 *  - orderStatus     : String, enum ['pending','processing','shipped','delivered','cancelled'], default 'pending'
 *  - itemsPrice      : Number, required
 *  - shippingPrice   : Number, required, default 0
 *  - taxPrice        : Number, required, default 0
 *  - discountAmount  : Number, default 0
 *  - totalPrice      : Number, required
 *  - coupon          : { code: String, discount: Number }
 *  - isPaid          : Boolean, default false
 *  - paidAt          : Date
 *  - isDelivered     : Boolean, default false
 *  - deliveredAt     : Date
 *  - trackingNumber  : String
 *  - notes           : String (buyer notes)
 *  - cancelReason    : String
 *  - timestamps      : true
 *
 * OrderItemSchema fields:
 *  - product  : ObjectId ref 'Product'
 *  - name     : String (snapshot)
 *  - image    : String (snapshot)
 *  - price    : Number (snapshot)
 *  - quantity : Number, min 1
 *  - subtotal : Number (price * quantity)
 *
 * HOOKS TO IMPLEMENT:
 *  - pre('save'): if isNew → generate orderNumber
 *      Format: 'ORD-' + new Date().getFullYear() + '-' + padded counter
 *      Or use: 'ORD-' + Date.now() for simplicity
 *
 * INDEXES:
 *  - { user: 1, createdAt: -1 } for user order history
 *  - { orderStatus: 1 } for admin order management
 *  - { orderNumber: 1 } unique
 *
 * TIPS:
 *  - ALWAYS snapshot product name/price/image — never reference live product data in orders
 *  - Calculate subtotal per item and total in the controller/service, store results
 */
