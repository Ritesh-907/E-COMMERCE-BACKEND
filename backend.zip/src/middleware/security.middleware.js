/**
 * middleware/security.middleware.js — Additional Security Middleware
 * ==================================================================
 * PURPOSE: Apply security hardening middleware in one place.
 *
 * EXPORT: configureSecurityMiddleware(app)
 *
 * IMPLEMENTATION:
 *  const configureSecurityMiddleware = (app) => {
 *    // Disable fingerprinting
 *    app.disable('x-powered-by')
 *
 *    // HTTP security headers (CSP, HSTS, etc.)
 *    app.use(helmet({
 *      contentSecurityPolicy: { directives: { defaultSrc: ["'self'"] } },
 *      crossOriginEmbedderPolicy: false  // Needed if serving images from CDN
 *    }))
 *
 *    // Prevent NoSQL injection: { "$gt": "" } in request body
 *    app.use(mongoSanitize())
 *
 *    // Sanitize HTML/JS in input to prevent XSS
 *    app.use(xss())
 *
 *    // Prevent HTTP parameter pollution: ?sort=name&sort=price
 *    app.use(hpp({ whitelist: ['sort', 'fields', 'tags', 'status'] }))
 *  }
 *
 * TIPS:
 *  - Whitelist HPP params that are legitimately arrays (sort, filter fields, tags)
 *  - Adjust helmet CSP if you serve static files from CDN (e.g. Cloudinary images)
 *  - Call this function in app.js before mounting routes
 */
