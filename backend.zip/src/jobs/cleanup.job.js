/**
 * jobs/cleanup.job.js — Scheduled Database Cleanup (node-cron)
 * ==============================================================
 * PURPOSE: Periodically remove expired/stale data from the database.
 *
 * INSTRUCTIONS:
 *  1. Import cron from 'node-cron', all needed models, logger
 *  2. Define individual cleanup functions:
 *
 *  deleteExpiredTokens()
 *    - RefreshToken.deleteMany({ expiresAt: { $lt: new Date() } })
 *    - Log count of deleted tokens
 *
 *  deleteOldNotifications()
 *    - Notification.deleteMany({ createdAt: { $lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } })
 *    - Backup: TTL index on Notification model handles this automatically too
 *
 *  cancelAbandonedOrders()
 *    - Find orders: { orderStatus: 'pending', paymentMethod: 'card', isPaid: false,
 *                     createdAt: { $lt: new Date(Date.now() - 24 * 60 * 60 * 1000) } }
 *    - For each: restore stock, set status 'cancelled', cancelReason 'Payment timeout'
 *    - Log count
 *
 *  3. Export initCleanupJobs():
 *       cron.schedule('0 0 * * *', deleteExpiredTokens)     // Daily at midnight
 *       cron.schedule('0 2 * * 0', deleteOldNotifications)  // Weekly Sunday 2 AM
 *       cron.schedule('0 */6 * * *', cancelAbandonedOrders) // Every 6 hours
 *       logger.info('Cleanup jobs initialized')
 *
 * CRON SYNTAX:
 *  '* * * * *' = minute hour day month weekday
 *  '0 0 * * *' = every day at midnight
 *  '*/30 * * * *' = every 30 minutes
 *
 * TIPS:
 *  - Wrap each job in try/catch so one failure doesn't stop others
 *  - In multi-instance deploys, only run jobs on ONE instance (use Redis lock)
 *  - Log job start + end + count of affected records for audit
 */
