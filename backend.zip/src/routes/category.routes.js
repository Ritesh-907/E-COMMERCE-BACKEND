/**
 * routes/category.routes.js — Category Routes
 * ==============================================
 * PURPOSE: Map category endpoints.
 *
 * ROUTES:
 *  GET    /          → cache(3600), getAllCategories     (public)
 *  GET    /:id       → getCategoryById                  (public)
 *
 *  POST   /          → protect, authorize('admin'), upload.single('image'), createCategory
 *  PATCH  /:id       → protect, authorize('admin'), upload.single('image'), updateCategory
 *  DELETE /:id       → protect, authorize('admin'), deleteCategory
 *
 * TIPS:
 *  - Cache category list aggressively (changes infrequently)
 *  - Bust cache in controller on every mutation
 */
