/**
 * services/notification.service.js — In-App Notification Service
 * ================================================================
 * PURPOSE: Create notifications and deliver them in real-time via Socket.IO.
 *
 * INSTRUCTIONS:
 *  1. Import Notification model
 *  2. Import getIO from sockets/index.js to access Socket.IO instance
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  createNotification({ userId, type, title, message, link, metadata })
 *    - Save to DB: Notification.create({ user: userId, type, title, message, link, metadata })
 *    - Deliver via Socket.IO: getIO().to(userId.toString()).emit('notification:new', notificationData)
 *    - Return saved notification
 *
 *  markAsRead(notificationId, userId)
 *    - Notification.findOneAndUpdate({ _id: notificationId, user: userId }, { isRead: true }, { new: true })
 *    - If not found → throw AppError(404)
 *
 *  markAllAsRead(userId)
 *    - Notification.updateMany({ user: userId, isRead: false }, { isRead: true })
 *    - Return count of updated documents
 *
 *  getUnreadCount(userId)
 *    - return Notification.countDocuments({ user: userId, isRead: false })
 *
 *  getUserNotifications(userId, page = 1, limit = 20)
 *    - Find with pagination, sort by createdAt desc
 *    - Return { notifications, unreadCount, pagination }
 *
 *  deleteNotification(notificationId, userId)
 *    - Notification.findOneAndDelete({ _id: notificationId, user: userId })
 *
 * USAGE (call from event listeners):
 *  notificationService.createNotification({
 *    userId: order.user, type: 'order',
 *    title: 'Order Confirmed', message: `Your order ${order.orderNumber} has been placed.`,
 *    link: `/orders/${order._id}`
 *  })
 *
 * TIPS:
 *  - Wrap Socket.IO emit in try/catch (user might be offline — that's fine)
 *  - createNotification should NOT throw if socket delivery fails (DB save is enough)
 *  - Emit getUnreadCount after creating to update badge in frontend
 */
