/**
 * routes/wishlist.routes.js — Wishlist Routes
 * ==============================================
 * PURPOSE: User wishlist management.
 *
 * ROUTES (all require protect):
 *  GET    /                     → getWishlist
 *  POST   /                     → validate(wishlistItemSchema), addToWishlist
 *  DELETE /:productId           → removeFromWishlist
 *  POST   /:productId/move-to-cart → moveToCart
 *
 * TIPS:
 *  - All wishlist routes require authentication
 *  - /:productId in DELETE and POST uses the product's _id, not a wishlist item _id
 */
