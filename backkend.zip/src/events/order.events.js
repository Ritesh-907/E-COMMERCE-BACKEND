'use strict';

/**
 * events/order.events.js — Order Domain Event Emitter
 * =====================================================
 * Decouples order side-effects from controllers.
 * Controllers emit events; listeners delegate to services.
 *
 * Events:
 *   order.created       — new order placed
 *   order.paid          — payment confirmed (via Stripe webhook)
 *   order.statusUpdated — admin changed order status
 *   order.cancelled     — order cancelled by user or admin
 */

const { EventEmitter } = require('events');

const logger = require('../utils/logger');
const { NOTIFICATION_TYPE } = require('../utils/enums');

// ── Lazy imports ──────────────────────────────────────────────────────────────
// Services are imported lazily inside handlers to break circular dependency
// chains (e.g. order.service → order.events → email.job → email.service)
// and to ensure all modules are fully initialised before first use.

const getNotificationService = () => require('../services/notification.service');
const getAddEmailJob         = () => require('../jobs/email.job').addEmailJob;

// ── Emitter instance ──────────────────────────────────────────────────────────

const orderEmitter = new EventEmitter();

// Raise the default limit (10) — we register multiple listeners across events.
// Set it high enough to silence Node's memory-leak warning without actually
// leaking (all listeners below are intentional singletons).
orderEmitter.setMaxListeners(20);

// ── order.created ─────────────────────────────────────────────────────────────
// Fired by: order.controller.js → createOrder

orderEmitter.on('order.created', async ({ order, user }) => {
  try {
    // Queue confirmation email (non-blocking; 3 automatic retries via Bull)
    await getAddEmailJob()('orderConfirm', user.email, { user, order });
  } catch (err) {
    logger.error('order.created: email job failed', {
      orderId: order._id,
      error:   err.message,
    });
  }

  try {
    await getNotificationService().createNotification({
      userId:   user._id,
      type:     NOTIFICATION_TYPE.ORDER,
      title:    'Order Placed Successfully',
      message:  `Your order #${order.orderNumber} has been confirmed.`,
      link:     `/orders/${order._id}`,
      metadata: { orderId: order._id },
    });
  } catch (err) {
    logger.error('order.created: notification failed', {
      orderId: order._id,
      error:   err.message,
    });
  }
});

// ── order.paid ────────────────────────────────────────────────────────────────
// Fired by: payment.controller.js → handleWebhook (payment_intent.succeeded)
// Note: user may not be available on req at this point — fetch from order

orderEmitter.on('order.paid', async ({ order }) => {
  // Fetch the user so we can address the notification correctly.
  // Use a try block so a missing user doesn't block the whole handler.
  let user;
  try {
    const User = require('../models/User');
    user = await User.findById(order.user).select('name email').lean();
  } catch (err) {
    logger.error('order.paid: failed to fetch user', {
      orderId: order._id,
      error:   err.message,
    });
    return;
  }

  if (!user) {
    logger.warn('order.paid: user not found — skipping notification', {
      orderId: order._id,
      userId:  order.user,
    });
    return;
  }

  try {
    await getNotificationService().createNotification({
      userId:   user._id,
      type:     NOTIFICATION_TYPE.ORDER,
      title:    'Payment Confirmed',
      message:  `Payment for order #${order.orderNumber} was successful. We're preparing your order.`,
      link:     `/orders/${order._id}`,
      metadata: { orderId: order._id },
    });
  } catch (err) {
    logger.error('order.paid: notification failed', {
      orderId: order._id,
      error:   err.message,
    });
  }

  try {
    await getAddEmailJob()('orderConfirm', user.email, { user, order });
  } catch (err) {
    logger.error('order.paid: email job failed', {
      orderId: order._id,
      error:   err.message,
    });
  }
});

// ── order.statusUpdated ───────────────────────────────────────────────────────
// Fired by: order.controller.js → updateOrderStatus, addTrackingNumber

orderEmitter.on('order.statusUpdated', async ({ order }) => {
  let user;
  try {
    const User = require('../models/User');
    user = await User.findById(order.user).select('name email').lean();
  } catch (err) {
    logger.error('order.statusUpdated: failed to fetch user', {
      orderId: order._id,
      error:   err.message,
    });
    return;
  }

  if (!user) return;

  // Build human-friendly status message
  const statusMessages = {
    processing: `Your order #${order.orderNumber} is being processed.`,
    shipped:    `Your order #${order.orderNumber} has been shipped.${order.trackingNumber ? ` Tracking: ${order.trackingNumber}.` : ''}`,
    delivered:  `Your order #${order.orderNumber} has been delivered. Enjoy!`,
    cancelled:  `Your order #${order.orderNumber} has been cancelled.`,
  };

  const message = statusMessages[order.orderStatus] ||
    `Your order #${order.orderNumber} status changed to "${order.orderStatus}".`;

  try {
    await getNotificationService().createNotification({
      userId:   user._id,
      type:     NOTIFICATION_TYPE.ORDER,
      title:    `Order ${capitalise(order.orderStatus)}`,
      message,
      link:     `/orders/${order._id}`,
      metadata: { orderId: order._id, status: order.orderStatus },
    });
  } catch (err) {
    logger.error('order.statusUpdated: notification failed', {
      orderId: order._id,
      error:   err.message,
    });
  }

  try {
    await getAddEmailJob()('orderStatus', user.email, { user, order });
  } catch (err) {
    logger.error('order.statusUpdated: email job failed', {
      orderId: order._id,
      error:   err.message,
    });
  }
});

// ── order.cancelled ───────────────────────────────────────────────────────────
// Fired by: order.controller.js → cancelOrder

orderEmitter.on('order.cancelled', async ({ order, user }) => {
  // user is always passed by cancelOrder controller
  try {
    await getNotificationService().createNotification({
      userId:   user._id,
      type:     NOTIFICATION_TYPE.ORDER,
      title:    'Order Cancelled',
      message:  `Your order #${order.orderNumber} has been cancelled.${
        order.paymentStatus === 'refunded' ? ' A refund has been initiated.' : ''
      }`,
      link:     `/orders/${order._id}`,
      metadata: { orderId: order._id },
    });
  } catch (err) {
    logger.error('order.cancelled: notification failed', {
      orderId: order._id,
      error:   err.message,
    });
  }

  // Only send a refund email if payment was actually refunded
  if (order.paymentStatus === 'refunded') {
    try {
      await getAddEmailJob()('orderStatus', user.email, { user, order });
    } catch (err) {
      logger.error('order.cancelled: refund email job failed', {
        orderId: order._id,
        error:   err.message,
      });
    }
  }
});

// ── Utility ───────────────────────────────────────────────────────────────────

function capitalise(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ─────────────────────────────────────────────────────────────────────────────

module.exports = orderEmitter;