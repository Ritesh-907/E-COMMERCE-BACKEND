/**
 * routes/payment.routes.js — Payment Routes
 * ============================================
 * PURPOSE: Stripe payment intents and webhook handling.
 *
 * !! CRITICAL: The /webhook route MUST use express.raw() body parser !!
 * !! It is mounted separately in app.js BEFORE express.json() !!
 *
 * ROUTES:
 *  POST /create-intent              → protect, createPaymentIntent
 *  POST /webhook                    → handleWebhook  (raw body — see app.js)
 *  POST /refund/:orderId            → protect, authorize('admin'), refundPayment
 *
 * IN app.js (before router mount):
 *  app.use('/api/v1/payments/webhook', express.raw({ type: 'application/json' }))
 *
 * TIPS:
 *  - /webhook must NOT use express.json() middleware — Stripe signature verification needs raw body
 *  - /create-intent uses the order's DB price, not any client-provided amount
 *  - Add idempotency key header to Stripe API calls
 */
