/**
 * config/jwt.js — JWT Configuration & Helpers
 * ==============================================
 * PURPOSE: Centralise JWT sign/verify logic in one place.
 *
 * INSTRUCTIONS:
 *  1. Export config object:
 *       {
 *         accessSecret:  process.env.JWT_SECRET,
 *         refreshSecret: process.env.JWT_REFRESH_SECRET,
 *         accessExpire:  process.env.JWT_EXPIRE,       // e.g. '15m'
 *         refreshExpire: process.env.JWT_REFRESH_EXPIRE // e.g. '7d'
 *       }
 *  2. Export helper functions:
 *       signAccessToken(payload)
 *         → jwt.sign(payload, accessSecret, { expiresIn: accessExpire, issuer: 'ecommerce-api' })
 *       signRefreshToken(payload)
 *         → jwt.sign(payload, refreshSecret, { expiresIn: refreshExpire })
 *       verifyAccessToken(token)
 *         → try jwt.verify(token, accessSecret) catch → throw AppError
 *       verifyRefreshToken(token)
 *         → try jwt.verify(token, refreshSecret) catch → throw AppError
 *
 * TIPS:
 *  - Keep access token payload minimal: { id, role } only
 *  - Add { audience: 'ecommerce-users' } to sign options for extra security
 *  - Throw AppError(401) on TokenExpiredError, AppError(401) on JsonWebTokenError
 */
