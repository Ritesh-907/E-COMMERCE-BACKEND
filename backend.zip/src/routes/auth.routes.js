/**
 * routes/auth.routes.js — Authentication Routes
 * ================================================
 * PURPOSE: Map auth endpoints to controller functions.
 *
 * ROUTES:
 *  POST   /register              → validate(registerSchema), authController.register
 *  POST   /login                 → authLimiter, validate(loginSchema), authController.login
 *  POST   /refresh-token         → authController.refreshToken
 *  POST   /logout                → protect, authController.logout
 *  POST   /forgot-password       → authLimiter, validate(forgotPasswordSchema), authController.forgotPassword
 *  PATCH  /reset-password/:token → validate(resetPasswordSchema), authController.resetPassword
 *  GET    /verify-email/:token   → authController.verifyEmail
 *  GET    /google                → passport.authenticate('google', { scope: ['profile', 'email'], session: false })
 *  GET    /google/callback       → passport.authenticate('google', { session: false, failureRedirect: '/login' }), authController.googleCallback
 *
 * IMPORTS NEEDED:
 *  express, authController, { protect } from auth.middleware,
 *  { authLimiter } from config/rateLimit, { validate } from validate.middleware,
 *  { registerSchema, loginSchema, ... } from auth.validator, passport
 *
 * TIPS:
 *  - Apply authLimiter on login + forgot-password to prevent brute force
 *  - Apply validate middleware BEFORE controller functions
 *  - OAuth routes do NOT use validate middleware (data comes from Google)
 */
