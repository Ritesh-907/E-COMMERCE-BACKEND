/**
 * middleware/upload.middleware.js — Multer File Upload Configuration
 * ====================================================================
 * PURPOSE: Handle multipart/form-data file uploads before controller execution.
 *
 * INSTRUCTIONS:
 *  1. Import multer, path, AppError
 *  2. Configure storage: use memoryStorage() so files are in req.file.buffer
 *     (This allows direct upload to Cloudinary/S3 without saving to disk)
 *  3. File filter function:
 *       const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
 *       (req, file, cb) => {
 *         if (ALLOWED_MIME_TYPES.includes(file.mimetype)) cb(null, true)
 *         else cb(new AppError('Only image files (jpeg, png, webp, gif) are allowed', 400), false)
 *       }
 *  4. Limits: { fileSize: 5 * 1024 * 1024 }  // 5MB per file
 *  5. Create multer instance: const multer = multer({ storage, fileFilter, limits })
 *
 * EXPORTS:
 *  upload.single('avatar')           → for user avatar updates
 *  upload.array('images', 5)         → for product images (max 5)
 *  upload.fields([                   → for mixed (e.g. product with thumbnail + gallery)
 *    { name: 'thumbnail', maxCount: 1 },
 *    { name: 'images', maxCount: 4 }
 *  ])
 *
 * TIPS:
 *  - Handle multer errors in error.middleware.js:
 *      if (err instanceof multer.MulterError) { ... handle LIMIT_FILE_SIZE etc. }
 *  - With memoryStorage, files are in req.file.buffer — pass to uploadService.uploadImage()
 *  - Validate file count: req.files?.length > MAX before uploading
 */
