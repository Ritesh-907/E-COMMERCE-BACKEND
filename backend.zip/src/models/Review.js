/**
 * models/Review.js — Review Schema & Model
 * ===========================================
 * PURPOSE: Store product reviews with rating recalculation.
 *
 * FIELDS TO INCLUDE:
 *  - product    : ObjectId ref 'Product', required
 *  - user       : ObjectId ref 'User', required
 *  - rating     : Number, required, min 1, max 5
 *  - title      : String, trim, maxLength 100
 *  - comment    : String, required, maxLength 1000
 *  - images     : [{ url: String, public_id: String }]
 *  - isVerified : Boolean, default false (has the user purchased this product?)
 *  - likes      : [{ type: ObjectId, ref: 'User' }]
 *  - timestamps : true
 *
 * INDEXES:
 *  - Compound unique: { product: 1, user: 1 } — one review per user per product
 *  - { product: 1, createdAt: -1 } for listing reviews by product
 *
 * STATICS TO IMPLEMENT:
 *  - Review.calcAverageRatings(productId):
 *      Use aggregate: [
 *        { $match: { product: productId } },
 *        { $group: { _id: '$product', average: { $avg: '$rating' }, count: { $sum: 1 } } }
 *      ]
 *      Update Product.findByIdAndUpdate(productId, { 'ratings.average': avg, 'ratings.count': count })
 *
 * HOOKS TO IMPLEMENT:
 *  - post('save'): await Review.calcAverageRatings(this.product)
 *  - post('deleteOne', { document: true }): await Review.calcAverageRatings(this.product)
 *
 * TIPS:
 *  - Round average to 1 decimal: Math.round(average * 10) / 10
 *  - isVerified check: Order.exists({ user, 'items.product': productId, isPaid: true })
 *  - likeCount virtual: return this.likes.length
 */
