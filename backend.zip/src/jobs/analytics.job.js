/**
 * jobs/analytics.job.js — Analytics Cache Pre-computation
 * ==========================================================
 * PURPOSE: Pre-compute and cache heavy analytics queries so the dashboard loads instantly.
 *
 * INSTRUCTIONS:
 *  1. Import cron, analyticsService, cacheService, logger
 *  2. Implement refreshAnalyticsCache():
 *       try {
 *         logger.info('Refreshing analytics cache...')
 *         const stats = await analyticsService.getDashboardStats()
 *         await cacheService.set('analytics:dashboard', stats, CACHE_TTL.ANALYTICS)
 *         const topProducts = await analyticsService.getTopSellingProducts(10)
 *         await cacheService.set('analytics:top-products', topProducts, CACHE_TTL.ANALYTICS)
 *         logger.info('Analytics cache refreshed successfully')
 *       } catch (err) {
 *         logger.error('Analytics cache refresh failed', { error: err.message })
 *       }
 *  3. Export initAnalyticsJobs():
 *       cron.schedule('0 * * * *', refreshAnalyticsCache)  // Every hour
 *       // Run once immediately on startup
 *       refreshAnalyticsCache()
 *       logger.info('Analytics jobs initialized')
 *
 * TIPS:
 *  - Run refreshAnalyticsCache() once at startup so cache is warm immediately
 *  - The analytics controller should try cache first, then fall back to live query
 *  - Add a timestamp to cached data: { ...stats, cachedAt: new Date().toISOString() }
 *    so admin UI can show 'Last updated: X mins ago'
 *  - In CACHE_TTL import from utils/constants.js
 */
