/**
 * events/order.events.js — Order Domain Event Emitter
 * =====================================================
 * PURPOSE: Decouple order side-effects from the controller using Node.js EventEmitter.
 *
 * INSTRUCTIONS:
 *  1. const { EventEmitter } = require('events')
 *     const orderEmitter = new EventEmitter()
 *     orderEmitter.setMaxListeners(20)  // Prevent memory leak warnings
 *
 *  2. Register event listeners:
 *
 *  orderEmitter.on('order.created', async ({ order, user }) => {
 *    try {
 *      await addEmailJob('orderConfirm', user.email, { user, order })
 *      await notificationService.createNotification({
 *        userId: user._id,
 *        type: NOTIFICATION_TYPE.ORDER,
 *        title: 'Order Placed Successfully',
 *        message: `Your order ${order.orderNumber} has been confirmed.`,
 *        link: `/orders/${order._id}`,
 *        metadata: { orderId: order._id }
 *      })
 *    } catch (err) { logger.error('order.created event handler failed', { err }) }
 *  })
 *
 *  orderEmitter.on('order.statusUpdated', async ({ order, user, oldStatus }) => {
 *    try {
 *      await addEmailJob('orderStatus', user.email, { user, order })
 *      await notificationService.createNotification({
 *        userId: user._id, type: NOTIFICATION_TYPE.ORDER,
 *        title: `Order ${order.orderStatus}`,
 *        message: `Your order ${order.orderNumber} status changed to ${order.orderStatus}.`,
 *        link: `/orders/${order._id}`
 *      })
 *    } catch (err) { logger.error('order.statusUpdated handler failed', { err }) }
 *  })
 *
 *  orderEmitter.on('order.cancelled', async ({ order, user }) => {
 *    try {
 *      await notificationService.createNotification({
 *        userId: user._id, type: NOTIFICATION_TYPE.ORDER,
 *        title: 'Order Cancelled',
 *        message: `Your order ${order.orderNumber} has been cancelled.`,
 *        link: `/orders/${order._id}`
 *      })
 *      // If refund was triggered: send refund notification too
 *    } catch (err) { logger.error('order.cancelled handler failed', { err }) }
 *  })
 *
 *  orderEmitter.on('order.paid', async ({ order, user }) => {
 *    try {
 *      await notificationService.createNotification({
 *        userId: user._id, type: NOTIFICATION_TYPE.ORDER,
 *        title: 'Payment Confirmed',
 *        message: `Payment for order ${order.orderNumber} was successful.`,
 *        link: `/orders/${order._id}`
 *      })
 *    } catch (err) { logger.error('order.paid handler failed', { err }) }
 *  })
 *
 *  3. module.exports = orderEmitter
 *
 * USAGE (in controllers):
 *  const orderEmitter = require('../events/order.events')
 *  orderEmitter.emit('order.created', { order, user: req.user })
 *
 * TIPS:
 *  - ALWAYS wrap each listener body in try/catch — an event error must not crash the server
 *  - Event handlers are fire-and-forget (don't await them in controllers)
 *  - Keep listeners thin — delegate to services (emailService, notificationService)
 */
