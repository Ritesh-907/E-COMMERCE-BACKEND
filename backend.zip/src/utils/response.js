/**
 * utils/response.js — Standardised API Response Helpers
 * ========================================================
 * PURPOSE: Enforce a consistent response shape across all controllers.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  successResponse(res, data, message = 'Success', statusCode = 200)
 *    res.status(statusCode).json({
 *      success: true,
 *      message,
 *      data
 *    })
 *
 *  paginatedResponse(res, data, pagination, message = 'Success')
 *    res.status(200).json({
 *      success: true,
 *      message,
 *      data,
 *      pagination: {
 *        total,
 *        page,
 *        limit,
 *        totalPages: Math.ceil(total / limit),
 *        hasNextPage: page < totalPages,
 *        hasPrevPage: page > 1
 *      }
 *    })
 *
 *  createdResponse(res, data, message = 'Created successfully')
 *    → successResponse(res, data, message, 201)
 *
 *  noContentResponse(res)
 *    → res.status(204).send()
 *
 * USAGE:
 *  return successResponse(res, { user }, 'Login successful')
 *  return paginatedResponse(res, products, { total, page, limit })
 *  return createdResponse(res, { order }, 'Order placed successfully')
 *
 * TIPS:
 *  - ALL controllers should use these helpers — never write res.json() inline
 *  - Frontend depends on this consistent { success, message, data } shape
 *  - The errorHandler in error.middleware.js uses the same shape for errors
 */
