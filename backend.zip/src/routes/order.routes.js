/**
 * routes/order.routes.js — Order Routes
 * ========================================
 * PURPOSE: Order creation and management.
 *
 * ROUTES (all require protect):
 *  POST   /                     → validate(createOrderSchema), createOrder
 *  GET    /my-orders            → getUserOrders
 *  GET    /:id                  → getOrderById
 *  PATCH  /:id/cancel           → cancelOrder
 *
 *  Admin only (require protect + authorize('admin')):
 *  GET    /admin/all            → getAllOrders
 *  PATCH  /admin/:id/status     → validate(updateOrderStatusSchema), updateOrderStatus
 *  PATCH  /admin/:id/tracking   → addTrackingNumber
 *
 * IMPORTANT:
 *  - /admin/all and /admin/:id/* routes must be defined BEFORE /:id routes
 *    to avoid Express treating 'admin' as a dynamic :id value
 *
 * TIPS:
 *  - All order routes require authentication
 *  - Ownership check is done inside getOrderById and cancelOrder controllers
 */
