/**
 * middleware/notFound.middleware.js — 404 Not Found Handler
 * ===========================================================
 * PURPOSE: Handle requests to routes that don't exist.
 *
 * IMPLEMENTATION:
 *  const notFound = (req, res, next) => {
 *    next(new AppError(`Cannot ${req.method} ${req.originalUrl}`, 404))
 *  }
 *  module.exports = { notFound }
 *
 * Mount in app.js AFTER all routes and BEFORE errorHandler:
 *  app.use(notFound)
 *  app.use(errorHandler)  // must be last
 *
 * TIPS:
 *  - Passing error to next() lets the global errorHandler format the response
 *  - Include both method and URL in message for easier debugging
 *  - The 404 response follows the same { success: false, message } shape
 */
