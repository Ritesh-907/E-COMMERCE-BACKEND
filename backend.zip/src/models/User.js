/**
 * models/User.js — User Schema & Model
 * =======================================
 * PURPOSE: Define the User MongoDB schema with auth and profile fields.
 *
 * FIELDS TO INCLUDE:
 *  - name              : String, required, trim, minLength 2, maxLength 50
 *  - email             : String, required, unique, lowercase, trim
 *  - password          : String, minLength 8, select: false
 *  - role              : String, enum ['user','admin','seller'], default 'user'
 *  - avatar            : { url: String, public_id: String }
 *  - phone             : String, trim
 *  - addresses         : [AddressSchema] (embed sub-document array)
 *  - googleId          : String (for OAuth users)
 *  - isVerified        : Boolean, default false
 *  - isActive          : Boolean, default true
 *  - emailVerifyToken  : String, select: false
 *  - emailVerifyExpire : Date, select: false
 *  - passwordResetToken: String, select: false
 *  - passwordResetExpire: Date, select: false
 *  - lastLogin         : Date
 *  - timestamps        : true
 *
 * AddressSchema fields:
 *  - street, city, state, zip, country: String
 *  - isDefault: Boolean, default false
 *  - label: String (e.g. 'Home', 'Office')
 *
 * METHODS & HOOKS TO IMPLEMENT:
 *  - pre('save'): if password is modified → bcrypt.hash(this.password, 12)
 *  - methods.comparePassword(candidate): bcrypt.compare(candidate, this.password)
 *  - methods.getPasswordResetToken():
 *      token = crypto.randomBytes(32).toString('hex')
 *      this.passwordResetToken = crypto.createHash('sha256').update(token).digest('hex')
 *      this.passwordResetExpire = Date.now() + 10 * 60 * 1000
 *      return token  (raw — send in email, store hashed)
 *  - methods.getEmailVerifyToken(): same pattern as above, 24h expiry
 *
 * TIPS:
 *  - Add index: { email: 1 } for fast lookups
 *  - add index: { googleId: 1 } for OAuth lookups
 *  - Virtual 'defaultAddress': return addresses.find(a => a.isDefault)
 *  - When setting a new default address, set all others to isDefault: false first
 */
