/**
 * config/redis.js — Redis Client
 * ================================
 * PURPOSE: Create a shared ioredis client used for caching, sessions, and queues.
 *
 * INSTRUCTIONS:
 *  1. Import Redis from 'ioredis'
 *  2. Create client:
 *       const redisClient = new Redis(process.env.REDIS_URL, {
 *         lazyConnect: true,
 *         retryStrategy: (times) => Math.min(times * 50, 2000),
 *         maxRetriesPerRequest: 3
 *       })
 *  3. Handle events:
 *       redisClient.on('connect', () => logger.info('Redis connected'))
 *       redisClient.on('error', err => logger.error('Redis error', { err }))
 *       redisClient.on('reconnecting', () => logger.warn('Redis reconnecting'))
 *  4. Export connectRedis() → await redisClient.connect()
 *  5. Export redisClient instance (used in cache.service.js, Bull queues)
 *
 * TIPS:
 *  - Wrap all Redis calls in try/catch — app must function even if Redis is down
 *  - Use lazyConnect: true so connection is established only when connectRedis() is called
 *  - Set keyPrefix: 'ec:' to namespace all keys from this app
 */
