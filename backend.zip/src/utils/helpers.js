/**
 * utils/helpers.js — General-Purpose Helper Functions
 * ======================================================
 * PURPOSE: Small reusable pure utility functions with no side effects.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  slugify(text)
 *    - Convert to lowercase, replace spaces/special chars with hyphens
 *    - 'Hello World!' → 'hello-world'
 *    - Use: text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').trim()
 *    - Or install the 'slugify' npm package for better Unicode support
 *
 *  generateOrderNumber()
 *    - Return: 'ORD-' + Date.now()  (simple approach)
 *    - Or: 'ORD-' + new Date().getFullYear() + '-' + String(counter).padStart(6, '0')
 *
 *  formatCurrency(amount, currency = 'USD', locale = 'en-US')
 *    - new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount)
 *    - Returns: '$1,234.56'
 *
 *  getPaginationMeta(total, page, limit)
 *    - totalPages = Math.ceil(total / limit)
 *    - return { total, page, limit, totalPages, hasNextPage: page < totalPages, hasPrevPage: page > 1 }
 *
 *  pickFields(obj, fields)
 *    - Return new object with only the specified fields
 *    - fields.reduce((acc, f) => { if (obj[f] !== undefined) acc[f] = obj[f]; return acc }, {})
 *
 *  omitFields(obj, fields)
 *    - Return new object without the specified fields (for stripping sensitive data)
 *    - Object.fromEntries(Object.entries(obj).filter(([k]) => !fields.includes(k)))
 *
 *  isValidObjectId(id)
 *    - return mongoose.isValidObjectId(id)
 *
 *  sleep(ms)
 *    - return new Promise(resolve => setTimeout(resolve, ms))
 *    - Useful for retry logic and testing
 *
 *  capitalizeFirst(str)
 *    - str.charAt(0).toUpperCase() + str.slice(1)
 *
 * TIPS:
 *  - Keep all functions PURE (no imports from services/models, no DB calls)
 *  - Test these thoroughly — they're used everywhere
 *  - Don't import helpers that create circular dependencies
 */
