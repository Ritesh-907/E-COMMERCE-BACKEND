/**
 * sockets/notification.socket.js — Real-Time Notification Handler
 * ==================================================================
 * PURPOSE: Handle client-side notification events over Socket.IO.
 *
 * EXPORT: notificationSocketHandler(io, socket)
 *
 * IMPLEMENTATION:
 *  module.exports = function notificationSocketHandler(io, socket) {
 *
 *    // Send unread count immediately on connect
 *    notificationService.getUnreadCount(socket.userId)
 *      .then(count => socket.emit('notification:count', { count }))
 *      .catch(() => {})
 *
 *    // Mark single notification as read
 *    socket.on('notification:read', async ({ notificationId }) => {
 *      try {
 *        await notificationService.markAsRead(notificationId, socket.userId)
 *        const count = await notificationService.getUnreadCount(socket.userId)
 *        socket.emit('notification:count', { count })
 *        socket.emit('notification:readConfirmed', { notificationId })
 *      } catch (err) { socket.emit('notification:error', { message: err.message }) }
 *    })
 *
 *    // Mark all as read
 *    socket.on('notification:readAll', async () => {
 *      try {
 *        await notificationService.markAllAsRead(socket.userId)
 *        socket.emit('notification:count', { count: 0 })
 *      } catch (err) { socket.emit('notification:error', { message: err.message }) }
 *    })
 *
 *    // Get unread count on demand
 *    socket.on('notification:getCount', async () => {
 *      try {
 *        const count = await notificationService.getUnreadCount(socket.userId)
 *        socket.emit('notification:count', { count })
 *      } catch (err) {}
 *    })
 *  }
 *
 * PUSH NOTIFICATIONS (from services/jobs — not here):
 *  getIO().to(userId.toString()).emit('notification:new', notificationData)
 *  getIO().to(userId.toString()).emit('notification:count', { count })
 *
 * TIPS:
 *  - All events from SERVER to CLIENT: notification:new, notification:count
 *  - All events from CLIENT to SERVER: notification:read, notification:readAll, notification:getCount
 *  - Send unread count on connect so badge updates immediately when user opens app
 */
