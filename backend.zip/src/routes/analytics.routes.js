/**
 * routes/analytics.routes.js — Analytics Routes
 * =================================================
 * PURPOSE: Admin-only analytics and dashboard data endpoints.
 *
 * ROUTES (all require protect + authorize('admin')):
 *  GET    /dashboard            → cache(300), getDashboardStats
 *  GET    /revenue              → cache(300), getRevenueChart       (query: period, from, to)
 *  GET    /top-products         → cache(600), getTopProducts        (query: limit)
 *  GET    /top-categories       → cache(600), getTopCategories
 *  GET    /user-growth          → cache(300), getUserGrowth         (query: period, from, to)
 *
 * TIPS:
 *  - All analytics routes are admin-only (apply authorize middleware)
 *  - Cache aggressively — these are expensive aggregations
 *  - Query param validation: period must be 'daily'|'weekly'|'monthly'
 */
