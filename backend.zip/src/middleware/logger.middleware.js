/**
 * middleware/logger.middleware.js — HTTP Request Logger
 * =======================================================
 * PURPOSE: Log all incoming HTTP requests with method, URL, status, and duration.
 *
 * INSTRUCTIONS:
 *  1. Import morgan and logger (from utils/logger.js)
 *  2. Create write stream for access log (production):
 *       const accessLogStream = fs.createWriteStream(
 *         path.join(__dirname, '../../logs/access.log'), { flags: 'a' }
 *       )
 *  3. Development logger:
 *       morgan('dev')  — colorful console output
 *  4. Production logger:
 *       morgan('combined', { stream: accessLogStream })
 *  5. Export based on NODE_ENV:
 *       module.exports = process.env.NODE_ENV === 'production' ? prodLogger : devLogger
 *
 * CUSTOM MORGAN TOKENS (optional but useful):
 *  morgan.token('user-id', req => req.user?.id || 'anonymous')
 *  morgan.token('body', req => JSON.stringify(req.body))  // Be careful with sensitive data!
 *
 * TIPS:
 *  - Skip health check route from logs: morgan({ skip: (req) => req.url === '/health' })
 *  - NEVER log request body in production (may contain passwords/credit cards)
 *  - Consider winston-daily-rotate-file for production log rotation
 */
