/**
 * models/Category.js — Category Schema & Model
 * ===============================================
 * PURPOSE: Hierarchical product categories (parent/child support).
 *
 * FIELDS TO INCLUDE:
 *  - name     : String, required, unique, trim
 *  - slug     : String, unique (auto-generated)
 *  - parent   : ObjectId ref 'Category', default null (null = top-level)
 *  - image    : { url: String, public_id: String }
 *  - isActive : Boolean, default true
 *  - order    : Number, default 0 (for manual sort in nav menus)
 *  - timestamps: true
 *
 * HOOKS TO IMPLEMENT:
 *  - pre('save'): generate slug from name if name is modified
 *
 * STATICS TO IMPLEMENT:
 *  - Category.buildTree(): fetch all active categories, build nested tree structure
 *      Result: [{ ...cat, children: [...subcats] }]
 *
 * TIPS:
 *  - For breadcrumbs: populate parent recursively (max 3 levels deep)
 *  - Before deleting a category, check Product.countDocuments({ category: id }) > 0
 *  - Add a 'path' virtual: e.g. 'Electronics > Phones > Android' (requires populated parent)
 */
