/**
 * config/cloudinary.js — Cloudinary SDK Setup
 * ==============================================
 * PURPOSE: Configure Cloudinary for image storage and transformation.
 *
 * INSTRUCTIONS:
 *  1. Import { v2 as cloudinary } from 'cloudinary'
 *  2. Configure:
 *       cloudinary.config({
 *         cloud_name: process.env.CLOUD_NAME,
 *         api_key:    process.env.CLOUD_API_KEY,
 *         api_secret: process.env.CLOUD_API_SECRET,
 *         secure: true
 *       })
 *  3. Export the configured cloudinary instance
 *  4. Export default upload options:
 *       const uploadOptions = {
 *         quality: 'auto',
 *         fetch_format: 'auto',
 *         flags: 'progressive'
 *       }
 *
 * TIPS:
 *  - Use folder per resource type: 'ecommerce/products', 'ecommerce/avatars'
 *  - Add eager transformations for thumbnails: { width: 300, height: 300, crop: 'thumb' }
 *  - Verify configuration on startup: call cloudinary.api.ping() and log result
 */
