/**
 * services/auth.service.js — Authentication Business Logic
 * ===========================================================
 * PURPOSE: Token generation, refresh token storage, and revocation.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  generateTokenPair(userId, userAgent, ip)
 *    - Generate accessToken:  signAccessToken({ id: userId })
 *    - Generate refreshToken: signRefreshToken({ id: userId })
 *    - Hash refreshToken: hashToken(refreshToken) from utils/tokenUtils.js
 *    - Save to DB: RefreshToken.create({
 *        token: hashedToken,
 *        user: userId,
 *        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
 *        userAgent,
 *        ip
 *      })
 *    - Return: { accessToken, refreshToken }  (raw refresh token — for cookie)
 *
 *  rotateRefreshToken(rawOldToken, userId, userAgent, ip)
 *    - Hash old token, find in DB, set isRevoked: true
 *    - Generate new token pair
 *    - Return new { accessToken, refreshToken }
 *
 *  revokeToken(rawToken)
 *    - Hash token, RefreshToken.findOneAndUpdate({ token: hash }, { isRevoked: true })
 *
 *  revokeAllUserTokens(userId)
 *    - RefreshToken.updateMany({ user: userId }, { isRevoked: true })
 *    - Use case: password change, security breach, admin action
 *
 *  verifyAndGetRefreshToken(rawToken)
 *    - Hash token
 *    - Find: RefreshToken.findOne({ token: hash, isRevoked: false, expiresAt: { $gt: now } })
 *    - If not found → throw AppError('Invalid or expired refresh token', 401)
 *    - Return the DB record
 *
 * TIPS:
 *  - Refresh token rotation: issue a new refresh token every time one is used
 *  - Track userAgent + IP on each refresh token for device management
 *  - Call revokeAllUserTokens after password change to force re-login on all devices
 */
