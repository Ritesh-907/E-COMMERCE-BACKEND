/**
 * utils/enums.js — Application Enumerations
 * ============================================
 * PURPOSE: Single source of truth for all enum values used in models, controllers, and validators.
 *
 * EXPORT THE FOLLOWING OBJECTS:
 *
 *  USER_ROLES = {
 *    USER:   'user',
 *    ADMIN:  'admin',
 *    SELLER: 'seller'
 *  }
 *
 *  ORDER_STATUS = {
 *    PENDING:    'pending',
 *    PROCESSING: 'processing',
 *    SHIPPED:    'shipped',
 *    DELIVERED:  'delivered',
 *    CANCELLED:  'cancelled'
 *  }
 *
 *  PAYMENT_STATUS = {
 *    PENDING:  'pending',
 *    PAID:     'paid',
 *    FAILED:   'failed',
 *    REFUNDED: 'refunded'
 *  }
 *
 *  PAYMENT_METHOD = {
 *    CARD:   'card',
 *    COD:    'cod',
 *    WALLET: 'wallet'
 *  }
 *
 *  COUPON_TYPE = {
 *    PERCENTAGE: 'percentage',
 *    FIXED:      'fixed'
 *  }
 *
 *  NOTIFICATION_TYPE = {
 *    ORDER:  'order',
 *    PROMO:  'promo',
 *    SYSTEM: 'system',
 *    REVIEW: 'review',
 *    STOCK:  'stock'
 *  }
 *
 *  // Valid order status transitions (used in updateOrderStatus controller)
 *  VALID_STATUS_TRANSITIONS = {
 *    pending:    ['processing', 'cancelled'],
 *    processing: ['shipped', 'cancelled'],
 *    shipped:    ['delivered'],
 *    delivered:  [],
 *    cancelled:  []
 *  }
 *
 * USAGE IN MODELS:
 *  role: { type: String, enum: Object.values(USER_ROLES), default: USER_ROLES.USER }
 *
 * TIPS:
 *  - Import and use enums instead of hardcoding strings like 'admin' everywhere
 *  - VALID_STATUS_TRANSITIONS prevents invalid order status updates (use in controller)
 */
