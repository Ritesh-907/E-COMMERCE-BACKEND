/**
 * scripts/createAdmin.js — First Admin User Creator
 * ====================================================
 * PURPOSE: Create the first admin user on a fresh deployment. Run once.
 *
 * INSTRUCTIONS:
 *  1. Load env: require('dotenv').config()
 *  2. Import mongoose, User model
 *  3. Connect to MongoDB
 *  4. Read credentials from environment variables:
 *       const name     = process.env.ADMIN_NAME     || 'Admin'
 *       const email    = process.env.ADMIN_EMAIL
 *       const password = process.env.ADMIN_PASS
 *       if (!email || !password) { console.error('Set ADMIN_EMAIL and ADMIN_PASS env vars'); process.exit(1) }
 *  5. Check for existing admin:
 *       const existing = await User.findOne({ role: 'admin' })
 *       if (existing) { console.log('Admin already exists:', existing.email); process.exit(0) }
 *  6. Create admin:
 *       await User.create({ name, email, password, role: 'admin', isVerified: true, isActive: true })
 *       console.log('✅ Admin created:', email)
 *  7. process.exit(0)
 *
 * USAGE:
 *  ADMIN_EMAIL=admin@yourstore.com ADMIN_PASS=SecurePass123! node scripts/createAdmin.js
 *
 * TIPS:
 *  - Never hardcode credentials in this file
 *  - The User model pre-save hook will hash the password automatically
 *  - After running, remove this script from deployment or add it to .gitignore
 *  - Log masked email (admin@***) not full details
 */
