/**
 * middleware/cache.middleware.js — Redis Response Caching
 * =========================================================
 * PURPOSE: Cache GET responses in Redis to reduce database load.
 *
 * EXPORTS:
 *  cache(ttlSeconds)   — middleware to cache responses
 *  invalidateCache(pattern) — utility to bust cache after mutations
 *
 * cache(ttl) implementation:
 *  return async (req, res, next) => {
 *    if (!redisClient.isReady) return next()  // Degrade gracefully if Redis is down
 *    const key = `cache:${req.originalUrl}`   // Includes query string for filtered results
 *    try {
 *      const cached = await redisClient.get(key)
 *      if (cached) return res.json(JSON.parse(cached))  // Cache hit
 *
 *      // Intercept res.json to store response
 *      const originalJson = res.json.bind(res)
 *      res.json = (data) => {
 *        if (res.statusCode === 200) {  // Only cache successful responses
 *          redisClient.setex(key, ttl, JSON.stringify(data)).catch(() => {})
 *        }
 *        return originalJson(data)
 *      }
 *      next()
 *    } catch (err) {
 *      next()  // Skip cache on error
 *    }
 *  }
 *
 * invalidateCache(pattern) implementation:
 *  - Use redisClient.scan(0, 'MATCH', pattern, 'COUNT', 100) to find matching keys
 *  - Delete all found keys with redisClient.del(keys)
 *  - Handle cursor-based SCAN (loop until cursor returns '0')
 *
 * USAGE:
 *  router.get('/', cache(300), getAllProducts)
 *  // In controller after mutation:
 *  await invalidateCache('cache:/api/v1/products*')
 *
 * TIPS:
 *  - Only cache public, user-agnostic routes (not user-specific data)
 *  - Add res.setHeader('X-Cache', cached ? 'HIT' : 'MISS') for debugging
 *  - Use JSON.parse/stringify for serialization — don't cache Buffer or functions
 */
