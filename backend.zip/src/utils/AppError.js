/**
 * utils/AppError.js — Custom Operational Error Class
 * =====================================================
 * PURPOSE: Create predictable errors with HTTP status codes for the global error handler.
 *
 * IMPLEMENTATION:
 *  class AppError extends Error {
 *    constructor(message, statusCode, errors = null) {
 *      super(message)
 *      this.statusCode  = statusCode
 *      this.status      = statusCode >= 400 && statusCode < 500 ? 'fail' : 'error'
 *      this.isOperational = true   // Safe to expose to client
 *      this.errors      = errors   // Optional array: [{ field, message }]
 *      Error.captureStackTrace(this, this.constructor)
 *    }
 *  }
 *  module.exports = AppError
 *
 * USAGE:
 *  throw new AppError('Email already registered', 400)
 *  throw new AppError('Validation failed', 422, [{ field: 'email', message: 'is required' }])
 *  next(new AppError('Product not found', 404))
 *
 * TIPS:
 *  - isOperational: true means "intentional app error — safe to show message to client"
 *  - In error.middleware.js: if (!err.isOperational) send generic 'Something went wrong'
 *  - errors array is used by validate middleware for field-level validation errors
 *  - Always use next(new AppError(...)) in async controllers (or use asyncHandler)
 */
