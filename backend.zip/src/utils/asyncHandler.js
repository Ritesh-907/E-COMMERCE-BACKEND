/**
 * utils/asyncHandler.js — Async Controller Wrapper
 * ==================================================
 * PURPOSE: Eliminate try/catch boilerplate in every async controller function.
 *
 * IMPLEMENTATION:
 *  const asyncHandler = (fn) => (req, res, next) =>
 *    Promise.resolve(fn(req, res, next)).catch(next)
 *
 *  module.exports = asyncHandler
 *
 * USAGE:
 *  const getAllProducts = asyncHandler(async (req, res) => {
 *    const products = await Product.find()
 *    res.json({ success: true, data: products })
 *    // No try/catch needed — errors go to next() automatically
 *  })
 *
 * TIPS:
 *  - .catch(next) passes ANY thrown error to Express's global error handler
 *  - Works with both thrown errors and rejected promises
 *  - Alternative: install 'express-async-errors' package and require it in app.js
 *    (automatically patches Express to handle async errors — no wrapper needed)
 */
