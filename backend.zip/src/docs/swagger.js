/**
 * docs/swagger.js — Swagger / OpenAPI Documentation Setup
 * ==========================================================
 * PURPOSE: Serve interactive API documentation at /api/v1/docs (development only).
 *
 * INSTRUCTIONS:
 *  1. Install dependencies:
 *       npm install swagger-ui-express swagger-jsdoc
 *  2. Configure swagger-jsdoc:
 *       const swaggerDefinition = {
 *         openapi: '3.0.0',
 *         info: {
 *           title: 'Ecommerce API',
 *           version: '1.0.0',
 *           description: 'Production-ready ecommerce REST API'
 *         },
 *         servers: [{ url: '/api/v1', description: 'API Server' }],
 *         components: {
 *           securitySchemes: {
 *             bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }
 *           }
 *         },
 *         security: [{ bearerAuth: [] }]
 *       }
 *       const options = {
 *         definition: swaggerDefinition,
 *         apis: ['./src/routes/*.js', './src/models/*.js']  // Reads @swagger JSDoc
 *       }
 *       const swaggerSpec = swaggerJsdoc(options)
 *
 *  3. Export setupSwagger(app):
 *       if (process.env.NODE_ENV !== 'production') {
 *         app.use('/api/v1/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec))
 *         app.get('/api/v1/docs.json', (req, res) => res.json(swaggerSpec))
 *         logger.info('Swagger docs available at /api/v1/docs')
 *       }
 *
 *  4. Add JSDoc @swagger comments to routes (example for product route):
 *       /**
 *        * @swagger
 *        * /products:
 *        *   get:
 *        *     summary: Get all products
 *        *     tags: [Products]
 *        *     parameters:
 *        *       - in: query
 *        *         name: page
 *        *         schema: { type: integer }
 *        *     responses:
 *        *       200:
 *        *         description: List of products
 *        *\/
 *
 * TIPS:
 *  - Only expose docs in non-production (security risk to expose API structure)
 *  - Use tags to group endpoints: Products, Orders, Users, Auth, etc.
 *  - Document all request bodies and response schemas for each endpoint
 */
