/**
 * controllers/cart.controller.js — Shopping Cart
 * =================================================
 * PURPOSE: Manage the authenticated user's shopping cart.
 * Wrap all functions with asyncHandler.
 *
 * HELPER:
 *  getOrCreateCart(userId)
 *    - Cart.findOne({ user: userId }) || new Cart({ user: userId, items: [] })
 *    - Return cart (not saved yet if new)
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getCart(req, res)
 *    - Find cart and populate:
 *        .populate({ path: 'items.product', select: 'name price images stock isPublished slug' })
 *        .populate('coupon', 'code type discount')
 *    - Remove items for deleted/unpublished products
 *    - Recalculate prices against live DB values (update item.price if changed)
 *    - Return 200: { success: true, data: { cart, totalItems, totalAmount } }
 *
 *  addToCart(req, res)
 *    - Validate: productId (ObjectId), quantity (positive integer)
 *    - Fetch product: if not found or !isPublished → AppError(404)
 *    - Check stock: product.stock >= quantity → AppError(400, 'Insufficient stock')
 *    - Get or create cart
 *    - Find existing item: cart.items.find(i => i.product.toString() === productId)
 *      - If exists: item.quantity += quantity (cap at product.stock)
 *      - If not: cart.items.push({ product: productId, quantity, price: product.price })
 *    - Save cart, return 200 with updated cart
 *
 *  updateCartItem(req, res)
 *    - Find item by params.itemId in cart.items
 *    - If not found → AppError(404, 'Item not in cart')
 *    - If quantity === 0: remove item (cart.items.pull(itemId))
 *    - Else: validate quantity <= product.stock, update item.quantity
 *    - Save, return 200 with cart
 *
 *  removeFromCart(req, res)
 *    - cart.items.pull(req.params.itemId)
 *    - Save, return 200 with cart
 *
 *  clearCart(req, res)
 *    - cart.items = []
 *    - cart.coupon = null
 *    - Save, return 200
 *
 *  applyCoupon(req, res)
 *    - couponService.validateAndApplyCoupon(code, userId, cartTotal)
 *    - If invalid: return 400 with reason
 *    - cart.coupon = coupon._id
 *    - Save, return 200 with discount info: { discountAmount, totalAfterDiscount }
 *
 *  removeCoupon(req, res)
 *    - cart.coupon = null
 *    - Save, return 200
 *
 * TIPS:
 *  - Always re-verify product stock on addToCart (race condition possible)
 *  - Consider merging guest cart (from request body) with user cart on first login
 *  - Use atomic operators ($set, $push, $pull) where possible for efficiency
 */
