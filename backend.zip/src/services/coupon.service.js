/**
 * services/coupon.service.js — Coupon Validation & Application
 * ==============================================================
 * PURPOSE: Validate coupon codes and calculate discount amounts.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  validateAndApplyCoupon(code, userId, orderTotal)
 *    - Find coupon: Coupon.findOne({ code: code.toUpperCase(), isActive: true })
 *    - If not found → return { valid: false, reason: 'Coupon not found' }
 *    - Check expiry: coupon.expiryDate < Date.now() → return { valid: false, reason: 'Coupon expired' }
 *    - Check start date: coupon.startDate > Date.now() → return { valid: false, reason: 'Coupon not yet active' }
 *    - Check usage limit: coupon.usageLimit && coupon.usedCount >= coupon.usageLimit
 *        → return { valid: false, reason: 'Coupon usage limit reached' }
 *    - Check per-user limit: filter usedBy for userId, count >= coupon.userLimit
 *        → return { valid: false, reason: 'You have already used this coupon' }
 *    - Check min order: orderTotal < coupon.minOrderValue
 *        → return { valid: false, reason: `Minimum order value is $${coupon.minOrderValue}` }
 *    - Calculate discount: coupon.calculateDiscount(orderTotal)
 *    - Return: { valid: true, discountAmount, coupon }
 *
 *  markCouponUsed(couponId, userId)
 *    - Coupon.findByIdAndUpdate(couponId, { $inc: { usedCount: 1 }, $push: { usedBy: userId } })
 *    - Call ONLY at order creation (not at validation time)
 *
 * TIPS:
 *  - This function returns an object (not throws) so controller can handle invalid gracefully
 *  - Case-insensitive search: store code in uppercase, search with .toUpperCase()
 *  - Log coupon usage with userId for analytics and fraud detection
 */
