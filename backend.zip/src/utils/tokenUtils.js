/**
 * utils/tokenUtils.js — JWT & Cryptographic Token Utilities
 * ===========================================================
 * PURPOSE: Generate, verify, and hash tokens used throughout the app.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  generateAccessToken(payload)
 *    - jwt.sign(payload, process.env.JWT_SECRET, {
 *        expiresIn: process.env.JWT_EXPIRE,
 *        issuer: 'ecommerce-api'
 *      })
 *    - payload should be: { id: user._id, role: user.role }
 *
 *  generateRefreshToken(payload)
 *    - jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
 *        expiresIn: process.env.JWT_REFRESH_EXPIRE
 *      })
 *
 *  verifyAccessToken(token)
 *    - try { return jwt.verify(token, process.env.JWT_SECRET) }
 *    - catch TokenExpiredError → throw new AppError('Token expired', 401)
 *    - catch JsonWebTokenError → throw new AppError('Invalid token', 401)
 *
 *  verifyRefreshToken(token)
 *    - Same as above but uses JWT_REFRESH_SECRET
 *
 *  generateRandomToken(bytes = 32)
 *    - return crypto.randomBytes(bytes).toString('hex')
 *    - Use for: email verify token, password reset token
 *    - Send RAW token to user, store HASHED in DB
 *
 *  hashToken(rawToken)
 *    - return crypto.createHash('sha256').update(rawToken).digest('hex')
 *    - Use to hash before storing, and to hash again when verifying
 *
 * TIPS:
 *  - Access token payload is small (id + role only) — it's sent on every request
 *  - generateRandomToken + hashToken is used in User model methods too (import from here)
 *  - Never store raw JWT refresh tokens or crypto tokens in the database
 */
