/**
 * jobs/email.job.js — Async Email Queue (Bull + Redis)
 * ======================================================
 * PURPOSE: Process email sends asynchronously with retry support.
 * Keeps email delivery from blocking API response time.
 *
 * INSTRUCTIONS:
 *  1. Import Bull, emailService, logger
 *  2. Create queue:
 *       const emailQueue = new Bull('email-queue', {
 *         redis: process.env.REDIS_URL,
 *         defaultJobOptions: {
 *           attempts: 3,
 *           backoff: { type: 'exponential', delay: 2000 },
 *           removeOnComplete: true,
 *           removeOnFail: false  // Keep failed jobs for inspection
 *         }
 *       })
 *  3. Register processor:
 *       emailQueue.process('sendEmail', async (job) => {
 *         const { type, to, data } = job.data
 *         switch (type) {
 *           case 'verification':    return emailService.sendVerificationEmail(data.user, data.token)
 *           case 'passwordReset':   return emailService.sendPasswordResetEmail(data.user, data.token)
 *           case 'orderConfirm':    return emailService.sendOrderConfirmation(data.user, data.order)
 *           case 'orderStatus':     return emailService.sendOrderStatusUpdate(data.user, data.order)
 *           case 'welcome':         return emailService.sendWelcomeEmail(data.user)
 *           case 'lowStock':        return emailService.sendLowStockAlert(data.adminEmail, data.products)
 *           default: throw new Error(`Unknown email type: ${type}`)
 *         }
 *       })
 *  4. Event listeners for monitoring:
 *       emailQueue.on('completed', job => logger.debug('Email sent', { jobId: job.id, type: job.data.type }))
 *       emailQueue.on('failed', (job, err) => logger.error('Email failed', { jobId: job.id, error: err.message }))
 *       emailQueue.on('stalled', job => logger.warn('Email job stalled', { jobId: job.id }))
 *  5. Export:
 *       addEmailJob(type, to, data) → emailQueue.add('sendEmail', { type, to, data })
 *       emailQueue (for monitoring)
 *
 * USAGE (in event listeners or controllers):
 *  import { addEmailJob } from './jobs/email.job.js'
 *  addEmailJob('orderConfirm', user.email, { user, order })
 *
 * TIPS:
 *  - Never send emails synchronously in controllers — always use this queue
 *  - Keep job payloads small — store only IDs, fetch data in processor if needed
 *  - Monitor with Bull Board: npm install @bull-board/express (optional dev tool)
 */
