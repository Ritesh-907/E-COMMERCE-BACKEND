/**
 * scripts/seed.js — Database Seeder
 * ====================================
 * PURPOSE: Populate the database with realistic sample data for development and testing.
 *
 * INSTRUCTIONS:
 *  1. Load env: require('dotenv').config()
 *  2. Import mongoose, all models, logger
 *  3. Connect to MongoDB: mongoose.connect(process.env.MONGO_URI)
 *
 *  4. Define seed data:
 *
 *  CATEGORIES (5-8 top-level + some sub-categories):
 *    [
 *      { name: 'Electronics', slug: 'electronics' },
 *      { name: 'Clothing', slug: 'clothing' },
 *      { name: 'Books', slug: 'books' },
 *      { name: 'Home & Garden', slug: 'home-garden' },
 *      { name: 'Sports', slug: 'sports' },
 *      // Sub-category example:
 *      { name: 'Smartphones', slug: 'smartphones', parent: electronicsId }
 *    ]
 *
 *  USERS (create with pre-hashed passwords OR let User model pre-save hook handle it):
 *    [
 *      { name: 'Admin User', email: 'admin@test.com', password: 'Admin123!', role: 'admin', isVerified: true },
 *      { name: 'Seller User', email: 'seller@test.com', password: 'Seller123!', role: 'seller', isVerified: true },
 *      { name: 'Test User', email: 'user@test.com', password: 'User1234!', role: 'user', isVerified: true },
 *      // Add 5-7 more users using @faker-js/faker
 *    ]
 *
 *  PRODUCTS (20-30 products spread across categories):
 *    - Use faker for: name, description, price, stock, brand, tags
 *    - Assign random categories, seller from above
 *    - Set isPublished: true for most
 *
 *  COUPONS:
 *    [
 *      { code: 'WELCOME10', type: 'percentage', discount: 10, expiryDate: future, isActive: true },
 *      { code: 'SAVE50', type: 'fixed', discount: 50, minOrderValue: 200, expiryDate: future },
 *    ]
 *
 *  5. Clear existing data first:
 *       await Promise.all([
 *         User.deleteMany(), Product.deleteMany(), Category.deleteMany(),
 *         Order.deleteMany(), Cart.deleteMany(), Review.deleteMany(), Coupon.deleteMany()
 *       ])
 *
 *  6. Insert in order (dependencies first):
 *       const categories = await Category.insertMany(categoryData)
 *       const users      = await User.create(userData)  // Use create() to trigger pre-save hooks (password hash)
 *       const products   = await Product.create(productData)
 *       await Coupon.insertMany(couponData)
 *
 *  7. Log: console.log('✅ Database seeded successfully')
 *  8. process.exit(0)
 *
 * USAGE:
 *  npm run seed                       → seed the database
 *  node scripts/seed.js --destroy     → only clear, don't re-seed
 *
 * TIPS:
 *  - Install @faker-js/faker for realistic data: npm i -D @faker-js/faker
 *  - Use User.create() not insertMany() for users (triggers password hashing pre-save hook)
 *  - Add process.argv check for --destroy flag to only clear without seeding
 *  - Move seed data arrays to database/factories/ for reuse in tests
 */
