/**
 * sockets/index.js — Socket.IO Server Initialization
 * =====================================================
 * PURPOSE: Initialize Socket.IO, authenticate connections, and register namespace handlers.
 *
 * INSTRUCTIONS:
 *  1. let io = null  (module-level singleton)
 *
 *  2. Export initSocket(httpServer):
 *       io = new Server(httpServer, {
 *         cors: { origin: process.env.CLIENT_URL, credentials: true },
 *         pingTimeout:  60000,
 *         pingInterval: 25000
 *       })
 *
 *  3. Add auth middleware (runs before connection):
 *       io.use(async (socket, next) => {
 *         const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1]
 *         if (!token) return next(new Error('Authentication required'))
 *         try {
 *           const decoded = verifyAccessToken(token)
 *           const user = await User.findById(decoded.id).select('_id role isActive')
 *           if (!user || !user.isActive) return next(new Error('User not found'))
 *           socket.userId   = user._id.toString()
 *           socket.userRole = user.role
 *           next()
 *         } catch (err) {
 *           next(new Error('Invalid token'))
 *         }
 *       })
 *
 *  4. On connection handler:
 *       io.on('connection', (socket) => {
 *         // Join user's personal room (for targeted notifications)
 *         socket.join(socket.userId)
 *         logger.debug('Socket connected', { socketId: socket.id, userId: socket.userId })
 *
 *         // Register feature handlers
 *         notificationSocketHandler(io, socket)
 *         chatSocketHandler(io, socket)
 *
 *         socket.on('disconnect', (reason) => {
 *           logger.debug('Socket disconnected', { socketId: socket.id, reason })
 *         })
 *       })
 *
 *  5. Export getIO():
 *       const getIO = () => {
 *         if (!io) throw new Error('Socket.IO not initialized')
 *         return io
 *       }
 *
 *  6. module.exports = { initSocket, getIO }
 *
 * USAGE (in services):
 *  const { getIO } = require('../sockets')
 *  getIO().to(userId).emit('notification:new', data)
 *
 * TIPS:
 *  - socket.join(userId) creates a private room — use io.to(userId).emit() for targeted messages
 *  - getIO() is the singleton accessor used throughout services/jobs
 *  - Admin room: if (socket.userRole === 'admin') socket.join('admin-room')
 *    Then: io.to('admin-room').emit('admin:alert', data)
 */
