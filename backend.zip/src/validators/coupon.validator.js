/**
 * validators/coupon.validator.js — Coupon Validation Schemas
 * ===========================================================
 * PURPOSE: Validate coupon create/update request bodies.
 *
 * SCHEMAS TO EXPORT:
 *
 *  createCouponSchema
 *    code:                Joi.string().min(3).max(20).uppercase().alphanum().required()
 *    type:                Joi.string().valid('percentage', 'fixed').required()
 *    discount:            Joi.number().positive().required()
 *                           .when('type', { is: 'percentage', then: Joi.number().max(100) })
 *    minOrderValue:       Joi.number().min(0).optional()
 *    maxDiscount:         Joi.number().positive().optional()
 *    usageLimit:          Joi.number().integer().positive().optional()
 *    userLimit:           Joi.number().integer().positive().default(1)
 *    startDate:           Joi.date().iso().optional()
 *    expiryDate:          Joi.date().iso().greater('now').required()
 *    isActive:            Joi.boolean().optional()
 *    description:         Joi.string().max(200).optional()
 *    applicableProducts:  Joi.array().items(Joi.string().hex().length(24)).optional()
 *    applicableCategories:Joi.array().items(Joi.string().hex().length(24)).optional()
 *
 *  updateCouponSchema
 *    Same but all optional. Use .fork() to make all fields optional.
 *
 *  validateCouponSchema (user endpoint)
 *    code:       Joi.string().required()
 *    orderTotal: Joi.number().positive().required()
 *
 * TIPS:
 *  - Percentage discount must be 1-100: use Joi.when() for conditional validation
 *  - maxDiscount only makes sense for percentage type — add note in schema comment
 *  - expiryDate must be in the future: .greater('now')
 */
