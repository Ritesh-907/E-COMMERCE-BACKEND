/**
 * routes/cart.routes.js — Shopping Cart Routes
 * ===============================================
 * PURPOSE: Cart CRUD for authenticated users.
 *
 * ROUTES (all require protect):
 *  GET    /                     → getCart
 *  POST   /items                → validate(addToCartSchema), addToCart
 *  PATCH  /items/:itemId        → validate(updateCartItemSchema), updateCartItem
 *  DELETE /items/:itemId        → removeFromCart
 *  DELETE /                     → clearCart
 *  POST   /coupon               → validate(couponSchema), applyCoupon
 *  DELETE /coupon               → removeCoupon
 *
 * TIPS:
 *  - All cart routes require authentication (no guest cart in this implementation)
 *  - Use router.route() to group same-path routes cleanly
 */
