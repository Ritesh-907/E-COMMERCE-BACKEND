/**
 * services/payment.service.js — Stripe Payment Service
 * =======================================================
 * PURPOSE: Encapsulate all Stripe API interactions.
 *
 * INSTRUCTIONS:
 *  1. Initialize Stripe:
 *       const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' })
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  createPaymentIntent(amount, currency = 'usd', metadata = {})
 *    - amount is in dollars (your app) — multiply by 100 for Stripe (cents)
 *    - stripe.paymentIntents.create({
 *        amount: Math.round(amount * 100),
 *        currency,
 *        metadata,
 *        automatic_payment_methods: { enabled: true }
 *      })
 *    - Return: { clientSecret: paymentIntent.client_secret, paymentIntentId: paymentIntent.id }
 *
 *  refundPayment(paymentIntentId, amount?)
 *    - stripe.refunds.create({
 *        payment_intent: paymentIntentId,
 *        amount: amount ? Math.round(amount * 100) : undefined  // undefined = full refund
 *      })
 *    - Return refund object
 *
 *  constructWebhookEvent(rawBody, signature, webhookSecret)
 *    - return stripe.webhooks.constructEvent(rawBody, signature, webhookSecret)
 *    - Throws if signature invalid (let it bubble up to handleWebhook controller)
 *
 *  retrievePaymentIntent(paymentIntentId)
 *    - return stripe.paymentIntents.retrieve(paymentIntentId)
 *
 * TIPS:
 *  - Amounts are ALWAYS in cents in Stripe — never forget to multiply by 100
 *  - Use idempotencyKey to prevent duplicate charges on retry:
 *      stripe.paymentIntents.create(data, { idempotencyKey: `order_${orderId}` })
 *  - Log full Stripe errors: err.raw for debugging
 *  - Test with Stripe test cards: 4242 4242 4242 4242 (success), 4000 0000 0000 9995 (decline)
 */
