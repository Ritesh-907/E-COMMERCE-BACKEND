/**
 * config/db.js — MongoDB Connection
 * ===================================
 * PURPOSE: Establish Mongoose connection and handle reconnection.
 *
 * INSTRUCTIONS:
 *  1. Import mongoose and logger
 *  2. Export async function connectDB():
 *       const conn = await mongoose.connect(process.env.MONGO_URI, {
 *         useNewUrlParser: true,
 *         useUnifiedTopology: true
 *       })
 *       logger.info(`MongoDB connected: ${conn.connection.host}`)
 *  3. Handle mongoose events:
 *       mongoose.connection.on('disconnected', () => logger.warn('MongoDB disconnected'))
 *       mongoose.connection.on('reconnected', () => logger.info('MongoDB reconnected'))
 *       mongoose.connection.on('error', err => logger.error('MongoDB error', { err }))
 *  4. In development enable query logging: mongoose.set('debug', true)
 *  5. Export mongoose.connection so server.js can call .close() on shutdown
 *
 * TIPS:
 *  - Wrap connect() in try/catch → on failure: logger.error + process.exit(1)
 *  - Set serverSelectionTimeoutMS: 5000 in options for faster failure in dev
 */
