/**
 * models/RefreshToken.js — Refresh Token Schema & Model
 * ========================================================
 * PURPOSE: Track issued refresh tokens to support rotation and revocation.
 *
 * FIELDS TO INCLUDE:
 *  - token     : String, required, unique (store SHA-256 HASH of the token)
 *  - user      : ObjectId ref 'User', required
 *  - expiresAt : Date, required
 *  - isRevoked : Boolean, default false
 *  - userAgent : String (browser/device info)
 *  - ip        : String
 *  - timestamps: true
 *
 * INDEXES:
 *  - { token: 1 } unique for fast lookup
 *  - { user: 1 } for revoking all user tokens
 *  - TTL index: { expiresAt: 1 }, expireAfterSeconds: 0 (auto-delete expired tokens)
 *
 * TIPS:
 *  - NEVER store the raw JWT — always store crypto.createHash('sha256').update(token).digest('hex')
 *  - On token rotation: revoke old record, create new one
 *  - On password change: RefreshToken.updateMany({ user }, { isRevoked: true })
 *  - On verify: find by hash AND isRevoked: false AND expiresAt > now
 */
