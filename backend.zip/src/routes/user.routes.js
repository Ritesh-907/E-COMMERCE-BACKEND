/**
 * routes/user.routes.js — User Profile Routes
 * ==============================================
 * PURPOSE: Map user profile and admin user management endpoints.
 *
 * ROUTES:
 *  All routes require: protect middleware
 *
 *  GET    /me                    → getMe
 *  PATCH  /me                    → upload.single('avatar'), validate(updateUserSchema), updateMe
 *  PATCH  /me/password           → validate(updatePasswordSchema), updatePassword
 *  DELETE /me                    → deleteMe
 *
 *  POST   /me/addresses          → validate(addressSchema), addAddress
 *  PATCH  /me/addresses/:addressId     → validate(addressSchema), updateAddress
 *  DELETE /me/addresses/:addressId     → deleteAddress
 *  PATCH  /me/addresses/:addressId/default → setDefaultAddress
 *
 *  Admin only (all require: authorize('admin')):
 *  GET    /                      → getAllUsers
 *  GET    /:id                   → getUserById
 *  PATCH  /:id                   → validate(adminUpdateUserSchema), updateUser
 *  DELETE /:id                   → deleteUser
 *
 * TIPS:
 *  - Apply upload.single('avatar') only on the PATCH /me route
 *  - Admin routes should be grouped with authorize('admin') after protect
 *  - Order matters: /me routes must come BEFORE /:id to avoid conflict
 */
