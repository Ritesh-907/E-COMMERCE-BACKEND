/**
 * middleware/authorize.middleware.js — Role-Based Access Control
 * ===============================================================
 * PURPOSE: Restrict access to routes based on user roles.
 *
 * EXPORT:
 *  authorize(...roles) — higher-order function returning middleware
 *
 * IMPLEMENTATION:
 *  const authorize = (...roles) => (req, res, next) => {
 *    // Must be used AFTER protect middleware (req.user must exist)
 *    if (!req.user) return next(new AppError('Authentication required', 401))
 *    if (!roles.includes(req.user.role)) {
 *      return next(new AppError(`Role '${req.user.role}' is not authorized for this action`, 403))
 *    }
 *    next()
 *  }
 *
 * USAGE IN ROUTES:
 *  router.delete('/:id', protect, authorize('admin'), deleteUser)
 *  router.post('/', protect, authorize('admin', 'seller'), createProduct)
 *
 * TIPS:
 *  - Always chain AFTER protect (never use alone)
 *  - Roles are defined in utils/enums.js — import from there
 *  - Error message deliberately vague to avoid info leakage
 */
