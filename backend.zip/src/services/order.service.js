/**
 * services/order.service.js — Order Calculation & Fulfillment
 * =============================================================
 * PURPOSE: Business logic for order creation, pricing, and stock management.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  calculateOrderTotals(items, couponDoc, shippingAddress)
 *    - items: [{ product: ProductDoc, quantity }]
 *    - itemsPrice  = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0)
 *    - shippingPrice = itemsPrice >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST
 *                      (import constants from utils/constants.js)
 *    - taxPrice    = Math.round(itemsPrice * TAX_RATE * 100) / 100
 *    - discountAmount = couponDoc ? couponDoc.calculateDiscount(itemsPrice) : 0
 *    - totalPrice  = itemsPrice + shippingPrice + taxPrice - discountAmount
 *    - Return: { itemsPrice, shippingPrice, taxPrice, discountAmount, totalPrice }
 *
 *  validateStock(items)
 *    - items: [{ productId, quantity }]
 *    - Fetch all products: Product.find({ _id: { $in: productIds } })
 *    - For each item: check product.stock >= quantity
 *    - Return: { valid: boolean, outOfStock: [{ productId, name, available, requested }] }
 *
 *  buildOrderItems(items, products)
 *    - Map items to order item format (snapshot name, image, price):
 *      [{ product, name: product.name, image: product.images[0]?.url, price: product.price, quantity, subtotal }]
 *
 *  decrementStock(orderItems, session?)
 *    - For each item: Product.findByIdAndUpdate(id, { $inc: { stock: -qty, sold: qty } }, { session })
 *    - Run inside a Mongoose session for atomicity
 *
 *  restoreStock(orderItems, session?)
 *    - Reverse: $inc { stock: +qty, sold: -qty }
 *    - Called on order cancellation
 *
 * TIPS:
 *  - ALWAYS fetch product prices from DB — never trust client-provided prices
 *  - Run decrementStock + order creation in a single Mongoose transaction
 *  - Math.round for monetary values to avoid floating point issues
 */
