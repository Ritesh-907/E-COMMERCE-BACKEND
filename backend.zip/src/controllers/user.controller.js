/**
 * controllers/user.controller.js — User Profile & Admin User Management
 * =======================================================================
 * PURPOSE: User profile CRUD, address management, admin user operations.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  --- Current User (protected routes) ---
 *
 *  getMe(req, res)
 *    - Return req.user (attached by auth middleware)
 *    - Populate addresses
 *    - Return 200: { success: true, data: { user } }
 *
 *  updateMe(req, res)
 *    - ONLY allow updating: name, phone, avatar
 *    - If req.file exists: upload to Cloudinary via uploadService.uploadImage()
 *      → delete old avatar from Cloudinary if it existed (old public_id)
 *    - Use pickFields(req.body, ['name', 'phone']) to prevent mass assignment
 *    - User.findByIdAndUpdate(req.user.id, fields, { new: true, runValidators: true })
 *    - Return 200 with updated user
 *
 *  updatePassword(req, res)
 *    - Require: currentPassword, newPassword, confirmPassword
 *    - Find user with password: User.findById(req.user.id).select('+password')
 *    - Verify currentPassword via user.comparePassword()
 *    - If wrong → AppError(401, 'Current password is incorrect')
 *    - Set user.password = newPassword, save
 *    - Revoke all refresh tokens: authService.revokeAllUserTokens(user._id)
 *    - Emit 'user.passwordChanged' event
 *    - Return new tokens (user is still logged in)
 *
 *  deleteMe(req, res)
 *    - Soft delete: User.findByIdAndUpdate(req.user.id, { isActive: false })
 *    - Revoke all tokens, clear cookie
 *    - Return 200: { success: true, message: 'Account deactivated.' }
 *
 *  --- Address Sub-Resource ---
 *
 *  addAddress(req, res)
 *    - Validate address fields (street, city, state, zip, country required)
 *    - If user has no addresses OR req.body.isDefault: set all existing to isDefault: false
 *    - Push new address to user.addresses
 *    - Save user, return 200 with updated addresses array
 *
 *  updateAddress(req, res)
 *    - Find address by req.params.addressId in user.addresses array (use .id() subdoc method)
 *    - If not found → AppError(404, 'Address not found')
 *    - Update fields, save
 *
 *  deleteAddress(req, res)
 *    - user.addresses.pull(req.params.addressId)
 *    - If deleted address was default and others exist → set first remaining as default
 *    - Save user
 *
 *  setDefaultAddress(req, res)
 *    - Loop user.addresses: set isDefault = (addr.id === params.addressId)
 *    - Save user, return 200
 *
 *  --- Admin Only ---
 *
 *  getAllUsers(req, res)
 *    - Use APIFeatures for pagination, filtering (role, isActive), search (name, email)
 *    - Return users array + pagination meta
 *    - Do NOT include password field
 *
 *  getUserById(req, res)
 *    - Find by params.id → if not found AppError(404)
 *    - Optionally add order count: Order.countDocuments({ user: id })
 *    - Return 200 with user data
 *
 *  updateUser(req, res)  [admin can update role, isActive only]
 *    - Only allow: role, isActive
 *    - Prevent admin from demoting themselves
 *    - Return 200 with updated user
 *
 *  deleteUser(req, res)  [hard delete — admin only]
 *    - Delete user and related data (cart, wishlist, refresh tokens)
 *    - Return 200: { success: true, message: 'User deleted.' }
 *
 * TIPS:
 *  - Never allow users to update their own role via updateMe
 *  - Use select('-password -emailVerifyToken -passwordResetToken') on all admin queries
 */
