/**
 * routes/product.routes.js — Product Routes
 * ============================================
 * PURPOSE: Map public catalog and admin product management endpoints.
 *
 * ROUTES:
 *  GET    /                   → cache(300), getAllProducts              (public)
 *  GET    /featured           → cache(3600), getFeaturedProducts        (public)
 *  GET    /:id                → getProductById                          (public)
 *  GET    /:id/related        → getRelatedProducts                      (public)
 *
 *  POST   /                   → protect, authorize('admin','seller'), upload.array('images', 5), validate(createProductSchema), createProduct
 *  PATCH  /:id                → protect, authorize('admin','seller'), checkOwnership(Product), upload.array('images', 5), updateProduct
 *  DELETE /:id                → protect, authorize('admin'), deleteProduct
 *
 *  Nested review router:
 *  router.use('/:productId/reviews', reviewRouter)  ← merge params: true
 *
 * IMPORTS NEEDED:
 *  express, productController, { protect } from auth.middleware,
 *  { authorize } from authorize.middleware, { upload } from upload.middleware,
 *  { cache } from cache.middleware, { checkOwnership } from ownership.middleware,
 *  { validate } from validate.middleware, Product model,
 *  reviewRouter (for nested routes)
 *
 * TIPS:
 *  - cache(300) = 5 min for product lists, cache(3600) = 1 hr for featured
 *  - For nested reviews: router.use('/:productId/reviews', reviewRouter) with mergeParams: true on reviewRouter
 *  - Invalidate product cache on mutations (done in controller)
 */
