/**
 * middleware/ownership.middleware.js — Resource Ownership Verification
 * ======================================================================
 * PURPOSE: Ensure a user can only modify their own resources (not others').
 *
 * EXPORT: checkOwnership(Model)
 *
 * IMPLEMENTATION:
 *  const checkOwnership = (Model) => async (req, res, next) => {
 *    const resource = await Model.findById(req.params.id)
 *    if (!resource) return next(new AppError('Resource not found', 404))
 *
 *    // Admin can access any resource
 *    if (req.user.role === 'admin') {
 *      req.resource = resource  // Attach for controller to reuse
 *      return next()
 *    }
 *
 *    // Check ownership — resource may have 'user' or 'seller' field
 *    const ownerId = resource.user?.toString() || resource.seller?.toString()
 *    if (ownerId !== req.user.id) {
 *      return next(new AppError('You are not authorized to modify this resource', 403))
 *    }
 *
 *    req.resource = resource  // Attach for controller to reuse (avoid re-fetch)
 *    next()
 *  }
 *
 * USAGE:
 *  router.patch('/:id', protect, checkOwnership(Product), updateProduct)
 *  // In controller: const product = req.resource  (no need to fetch again)
 *
 * TIPS:
 *  - Must be used AFTER protect middleware (req.user must exist)
 *  - Attach req.resource to avoid double DB queries in controller
 *  - Admin bypass is important for support/moderation use cases
 */
