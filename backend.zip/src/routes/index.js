/**
 * routes/index.js — Main Router Aggregator
 * ==========================================
 * PURPOSE: Mount all sub-routers and provide a health check endpoint.
 *
 * INSTRUCTIONS:
 *  const router = express.Router()
 *
 *  // Health check
 *  router.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime(), timestamp: Date.now() }))
 *
 *  // Mount all sub-routers
 *  router.use('/auth',       require('./auth.routes'))
 *  router.use('/users',      require('./user.routes'))
 *  router.use('/products',   require('./product.routes'))
 *  router.use('/categories', require('./category.routes'))
 *  router.use('/orders',     require('./order.routes'))
 *  router.use('/cart',       require('./cart.routes'))
 *  router.use('/reviews',    require('./review.routes'))
 *  router.use('/coupons',    require('./coupon.routes'))
 *  router.use('/payments',   require('./payment.routes'))
 *  router.use('/wishlist',   require('./wishlist.routes'))
 *  router.use('/analytics',  require('./analytics.routes'))
 *
 *  module.exports = router
 *
 * TIPS:
 *  - Apply generalLimiter here once rather than in every sub-router
 *  - Keep this file minimal — no middleware logic, just mounting
 */
