/**
 * middleware/auth.middleware.js — JWT Authentication Middleware
 * ==============================================================
 * PURPOSE: Verify JWT access token and attach req.user on protected routes.
 *
 * EXPORTS:
 *  protect       — requires valid JWT, rejects unauthenticated requests
 *  optionalAuth  — attaches user if token present, but allows requests without token
 *
 * protect(req, res, next):
 *  1. Extract token from TWO places (in order):
 *       a) Authorization header: 'Bearer <token>'
 *       b) req.cookies.accessToken
 *  2. If no token → next(AppError('Authentication required', 401))
 *  3. Verify token: verifyAccessToken(token) from utils/tokenUtils.js
 *       Catch TokenExpiredError → AppError('Session expired. Please log in again.', 401)
 *       Catch JsonWebTokenError → AppError('Invalid token. Please log in again.', 401)
 *  4. Fetch user: User.findById(decoded.id).select('-password -emailVerifyToken -passwordResetToken')
 *  5. If !user || !user.isActive → AppError('Account not found or deactivated.', 401)
 *  6. Optional — check password changed after token was issued:
 *       if (user.passwordChangedAt && user.passwordChangedAt > new Date(decoded.iat * 1000))
 *         → AppError('Password was changed. Please log in again.', 401)
 *  7. Set req.user = user → next()
 *
 * optionalAuth(req, res, next):
 *  - Same logic but if no token OR verification fails → just next() without setting req.user
 *  - Useful for public endpoints that behave differently when user is logged in
 *
 * TIPS:
 *  - Select only necessary fields from User (performance)
 *  - Never log the raw token value
 *  - Always check isActive on every request (user might be deactivated mid-session)
 */
