/**
 * models/Coupon.js — Coupon Schema & Model
 * ==========================================
 * PURPOSE: Define discount coupons for checkout.
 *
 * FIELDS TO INCLUDE:
 *  - code              : String, required, unique, uppercase, trim
 *  - type              : String, enum ['percentage','fixed'], required
 *  - discount          : Number, required, min 0
 *  - minOrderValue     : Number, default 0
 *  - maxDiscount       : Number (cap for percentage type — e.g. max $50 off)
 *  - usageLimit        : Number, default null (null = unlimited)
 *  - usedCount         : Number, default 0
 *  - userLimit         : Number, default 1 (uses per user)
 *  - usedBy            : [{ type: ObjectId, ref: 'User' }]
 *  - applicableProducts  : [ObjectId ref 'Product'] (empty = all products)
 *  - applicableCategories: [ObjectId ref 'Category'] (empty = all categories)
 *  - startDate         : Date, default Date.now
 *  - expiryDate        : Date, required
 *  - isActive          : Boolean, default true
 *  - description       : String (internal note for admins)
 *  - timestamps        : true
 *
 * HOOKS:
 *  - pre('save'): this.code = this.code.toUpperCase()
 *
 * METHODS TO IMPLEMENT:
 *  - methods.isValid(userId, orderTotal):
 *      Check: isActive, expiryDate > now, usedCount < usageLimit,
 *             usedBy filter for userId count < userLimit,
 *             orderTotal >= minOrderValue
 *      Return: true or throw AppError with reason
 *  - methods.calculateDiscount(orderTotal):
 *      if percentage: Math.min((discount / 100) * orderTotal, maxDiscount || Infinity)
 *      if fixed: Math.min(discount, orderTotal)
 *
 * TIPS:
 *  - Never let discount exceed orderTotal (minimum final price = 0)
 *  - Use sparse index on code for performance
 */
