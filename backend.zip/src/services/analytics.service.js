/**
 * services/analytics.service.js — MongoDB Analytics Aggregations
 * ================================================================
 * PURPOSE: Pre-built aggregation pipelines for admin dashboard.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getDashboardStats()
 *    - Use $facet for one round-trip:
 *      {
 *        totalRevenue:   [{ $match: { isPaid: true } }, { $group: { _id: null, total: { $sum: '$totalPrice' } } }],
 *        ordersByStatus: [{ $group: { _id: '$orderStatus', count: { $sum: 1 } } }],
 *        revenueToday:   [{ $match: { isPaid: true, paidAt: { $gte: startOfToday } } }, ...],
 *        topProduct:     [{ $unwind: '$items' }, { $group: { _id: '$items.product', sold: { $sum: '$items.quantity' } } }, { $sort: { sold: -1 } }, { $limit: 1 }]
 *      }
 *    - Separate query for user stats (User model)
 *    - Separate query for low-stock products
 *    - Cache result with 5 min TTL
 *
 *  getRevenueByPeriod(startDate, endDate, groupBy = 'day')
 *    - dateFormat: day='%Y-%m-%d', week='%Y-W%U', month='%Y-%m'
 *    - Pipeline: match isPaid + date range → group by dateToString → sort by date
 *    - Return: [{ _id: dateString, revenue, orderCount }]
 *
 *  getTopSellingProducts(limit = 10)
 *    - Order.aggregate: unwind items, group by product, sum quantity, sort desc, limit
 *    - Lookup to Product for name/images
 *    - Return: [{ productId, name, sold, revenue, image }]
 *
 *  getUserStats()
 *    - Total users, users registered today/this week/this month
 *    - Active users (lastLogin within 30 days)
 *    - Use $facet for one query
 *
 * TIPS:
 *  - Always add { $match: { isPaid: true } } at start of revenue pipelines
 *  - Cache all results (5-15 min TTL in Redis via cacheService.remember())
 *  - Use new Date() carefully — get startOfDay/endOfDay correctly for filtering
 */
