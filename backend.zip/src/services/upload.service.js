/**
 * services/upload.service.js — File Upload to Cloudinary / S3
 * ==============================================================
 * PURPOSE: Handle image upload, transformation, and deletion.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  uploadImage(fileBuffer, folder, publicId?)
 *    - Convert buffer to base64 data URI or use upload_stream
 *    - Cloudinary upload_stream approach (recommended for Node.js):
 *        return new Promise((resolve, reject) => {
 *          const stream = cloudinary.uploader.upload_stream(
 *            { folder, public_id: publicId, quality: 'auto', fetch_format: 'auto' },
 *            (error, result) => error ? reject(error) : resolve({ url: result.secure_url, public_id: result.public_id })
 *          )
 *          bufferToStream(fileBuffer).pipe(stream)
 *        })
 *    - bufferToStream: use stream.PassThrough to convert buffer to readable stream
 *
 *  uploadMultipleImages(files, folder)
 *    - files: [{ buffer, originalname }] (from multer memoryStorage)
 *    - return Promise.all(files.map(file => uploadImage(file.buffer, folder)))
 *    - Returns: [{ url, public_id }]
 *
 *  deleteImage(publicId)
 *    - cloudinary.uploader.destroy(publicId)
 *    - Return result
 *
 *  deleteMultipleImages(publicIds)
 *    - cloudinary.api.delete_resources(publicIds)
 *    - Use when deleting a product with multiple images
 *
 *  generateThumbnailUrl(publicId, width = 300, height = 300)
 *    - cloudinary.url(publicId, { width, height, crop: 'thumb', quality: 'auto' })
 *    - Returns transformed URL without re-uploading
 *
 * TIPS:
 *  - Use bufferToStream helper to convert multer buffer to stream (required by upload_stream)
 *  - folder naming: 'ecommerce/products', 'ecommerce/avatars', 'ecommerce/reviews'
 *  - Add error handling: if Cloudinary fails, log and throw AppError
 */
