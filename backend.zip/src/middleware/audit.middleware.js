/**
 * middleware/audit.middleware.js — Audit Trail Logging
 * ======================================================
 * PURPOSE: Log sensitive operations for security and compliance audit.
 *
 * EXPORT: auditLog(action)
 *
 * IMPLEMENTATION:
 *  const auditLog = (action) => (req, res, next) => {
 *    res.on('finish', () => {  // Log AFTER response is sent
 *      logger.info('AUDIT', {
 *        action,
 *        userId:     req.user?.id,
 *        userRole:   req.user?.role,
 *        ip:         req.ip || req.headers['x-forwarded-for'],
 *        userAgent:  req.headers['user-agent'],
 *        method:     req.method,
 *        path:       req.originalUrl,
 *        statusCode: res.statusCode,
 *        timestamp:  new Date().toISOString()
 *      })
 *    })
 *    next()
 *  }
 *
 * APPLY TO THESE ROUTES:
 *  - POST   /auth/login              → auditLog('USER_LOGIN')
 *  - POST   /auth/logout             → auditLog('USER_LOGOUT')
 *  - PATCH  /users/me/password       → auditLog('PASSWORD_CHANGE')
 *  - DELETE /users/:id               → auditLog('USER_DELETE')
 *  - PATCH  /users/:id               → auditLog('ADMIN_UPDATE_USER')
 *  - POST   /payments/refund/:id     → auditLog('PAYMENT_REFUND')
 *
 * TIPS:
 *  - NEVER log passwords, tokens, or card numbers
 *  - Store audit logs in a separate file/collection for compliance
 *  - res.on('finish') runs after response is sent (non-blocking)
 */
