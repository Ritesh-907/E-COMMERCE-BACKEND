/**
 * config/passport.js — Passport.js Strategy Configuration
 * ==========================================================
 * PURPOSE: Set up JWT and Google OAuth strategies.
 *
 * INSTRUCTIONS:
 *  1. Import passport, { Strategy: JwtStrategy, ExtractJwt }, { Strategy: GoogleStrategy }
 *  2. JWT Strategy:
 *       new JwtStrategy({
 *         jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
 *         secretOrKey: process.env.JWT_SECRET
 *       }, async (payload, done) => {
 *         const user = await User.findById(payload.id).select('-password')
 *         if (!user || !user.isActive) return done(null, false)
 *         return done(null, user)
 *       })
 *  3. Google OAuth Strategy:
 *       new GoogleStrategy({
 *         clientID:     process.env.GOOGLE_CLIENT_ID,
 *         clientSecret: process.env.GOOGLE_CLIENT_SECRET,
 *         callbackURL:  '/api/v1/auth/google/callback'
 *       }, async (accessToken, refreshToken, profile, done) => {
 *         // Find user by googleId, or create new user from profile
 *         // Set isVerified: true (Google verified the email)
 *         // Save profile picture as avatar.url
 *         return done(null, user)
 *       })
 *  4. Register both strategies: passport.use(jwtStrategy); passport.use(googleStrategy)
 *  5. Export initPassport(app) → app.use(passport.initialize())
 *
 * TIPS:
 *  - No sessions needed (stateless JWT API) — no serializeUser/deserializeUser
 *  - On Google login, generate your own JWT pair (don't use Google's tokens)
 *  - Check if user exists by email first (not just googleId) to handle account merging
 */
