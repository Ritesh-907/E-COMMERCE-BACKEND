/**
 * controllers/wishlist.controller.js — Wishlist Management
 * ===========================================================
 * PURPOSE: Add/remove/view products in user wishlist.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getWishlist(req, res)
 *    - Wishlist.findOne({ user: req.user.id })
 *        .populate({ path: 'products', select: 'name price comparePrice images stock ratings isPublished slug' })
 *    - Filter out unpublished products from the populated list
 *    - Return 200: { success: true, data: { wishlist, count: products.length } }
 *
 *  addToWishlist(req, res)
 *    - Validate: productId must be a valid ObjectId
 *    - Check product exists: Product.findById(productId) → AppError(404) if not
 *    - Wishlist.findOneAndUpdate(
 *        { user: req.user.id },
 *        { $addToSet: { products: productId } },
 *        { upsert: true, new: true }
 *      )
 *    - Return 200: { success: true, message: 'Added to wishlist' }
 *
 *  removeFromWishlist(req, res)
 *    - Wishlist.findOneAndUpdate(
 *        { user: req.user.id },
 *        { $pull: { products: req.params.productId } },
 *        { new: true }
 *      )
 *    - Return 200: { success: true, message: 'Removed from wishlist' }
 *
 *  moveToCart(req, res)
 *    - Fetch product, validate it's available and in stock
 *    - Add to cart: same logic as cart.controller.addToCart
 *    - Remove from wishlist: $pull
 *    - Return 200: { success: true, message: 'Moved to cart' }
 *
 * TIPS:
 *  - Return isInWishlist: boolean on product list endpoints for quick UI checks
 *  - Use upsert: true in findOneAndUpdate to create wishlist on first add
 *  - Limit: check products.length < 100 before $addToSet (optional)
 */
