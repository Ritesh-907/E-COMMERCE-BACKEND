/**
 * validators/user.validator.js — User Profile Validation Schemas
 * ================================================================
 * PURPOSE: Validate user profile update and address request bodies.
 *
 * SCHEMAS TO EXPORT:
 *
 *  updateUserSchema (for users updating their own profile — /me)
 *    name:  Joi.string().min(2).max(50).trim().optional()
 *    phone: Joi.string().pattern(/^[+\d\s\-()]{7,20}$/).optional()
 *    NOTE: Do NOT include email, role, password, isActive (those are separate flows)
 *
 *  adminUpdateUserSchema (for admin updating any user)
 *    role:     Joi.string().valid('user', 'admin', 'seller').optional()
 *    isActive: Joi.boolean().optional()
 *
 *  addressSchema (for addAddress and updateAddress)
 *    street:    Joi.string().max(200).required()
 *    city:      Joi.string().max(100).required()
 *    state:     Joi.string().max(100).required()
 *    zip:       Joi.string().max(20).required()
 *    country:   Joi.string().max(100).required()
 *    label:     Joi.string().valid('Home', 'Office', 'Other').optional()
 *    isDefault: Joi.boolean().optional()
 *    phone:     Joi.string().optional()
 *
 * TIPS:
 *  - Use .optional() for PATCH routes (not all fields required)
 *  - Validate phone with a pattern that accepts international formats
 *  - Never validate role or isActive in the "self-update" schema
 */
