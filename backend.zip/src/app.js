// /**
//  * app.js — Express Application Setup
//  * ====================================
//  * PURPOSE: Create and configure the Express app (middleware stack + routes).
//  *
//  * INSTRUCTIONS:
//  *  1. Create app: const app = express()
//  *  2. Trust proxy (for rate limiting behind Nginx/load balancer):
//  *       app.set('trust proxy', 1)
//  *  3. Apply security middleware IN THIS ORDER:
//  *       app.use(helmet())
//  *       app.use(mongoSanitize())
//  *       app.use(xss())
//  *       app.use(hpp({ whitelist: ['sort', 'fields', 'page', 'limit'] }))
//  *  4. Apply CORS: app.use(cors(corsOptions))  ← import from ./config/cors.js
//  *  5. Body parsers:
//  *       app.use('/api/v1/payments/webhook', express.raw({ type: '*/*' }))  ← BEFORE json parser
//  *       app.use(express.json({ limit: '10kb' }))
//  *       app.use(express.urlencoded({ extended: true, limit: '10kb' }))
//  *  6. Cookie parser: app.use(cookieParser())
//  *  7. Compression: app.use(compression())
//  *  8. Request logger: app.use(requestLogger)  ← import from ./middleware/logger.middleware.js
//  *  9. Static files: app.use('/uploads', express.static('uploads'))
//  * 10. Health check: app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }))
//  * 11. Mount rate limiter on API: app.use('/api', generalLimiter)
//  * 12. Mount all routes: app.use('/api/v1', router)  ← import from ./routes/index.js
//  * 13. 404 handler: app.use(notFound)
//  * 14. Global error handler: app.use(errorHandler)  ← MUST BE LAST
//  * 15. Export app
//  *
//  * TIPS:
//  *  - Stripe webhook MUST use raw body — mount it before express.json()
//  *  - Only enable Swagger in development (import from ./docs/swagger.js)
//  *  - Disable 'x-powered-by' header: app.disable('x-powered-by')
//     *  - Use helmet() with default options for good security defaults
// **/
import express from express;
const app = express();

app.set('trust proxy',1);
app.use