/**
 * services/email.service.js — Transactional Email Service
 * ==========================================================
 * PURPOSE: Send all app emails via Nodemailer with HTML templates.
 *
 * INSTRUCTIONS:
 *  1. Create transporter:
 *       nodemailer.createTransport({
 *         host: process.env.SMTP_HOST,
 *         port: process.env.SMTP_PORT,
 *         auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
 *       })
 *  2. Create base sendEmail(options) function:
 *       transporter.sendMail({ from, to, subject, html })
 *  3. Create HTML template helper: buildEmailTemplate(title, content, ctaUrl?, ctaText?)
 *       Returns full HTML string with brand logo, consistent header/footer
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  sendVerificationEmail(user, rawToken)
 *    - verifyUrl = `${process.env.CLIENT_URL}/verify-email/${rawToken}`
 *    - Subject: 'Verify your email address'
 *    - Content: greeting, explanation, CTA button linking to verifyUrl
 *    - Mention: link expires in 24 hours
 *
 *  sendPasswordResetEmail(user, rawToken)
 *    - resetUrl = `${process.env.CLIENT_URL}/reset-password/${rawToken}`
 *    - Subject: 'Password reset request'
 *    - Content: if you didn't request this ignore it, CTA button, 10 min expiry warning
 *
 *  sendOrderConfirmation(user, order)
 *    - Subject: `Order Confirmed - ${order.orderNumber}`
 *    - Content: order summary table (items, qty, prices), shipping address, total, estimated delivery
 *
 *  sendOrderStatusUpdate(user, order)
 *    - Subject: `Order ${order.orderNumber} - Status Updated to ${order.orderStatus}`
 *    - Content: new status, tracking number if shipped, estimated delivery
 *
 *  sendWelcomeEmail(user)
 *    - Subject: 'Welcome to [Store Name]!'
 *    - Content: brief welcome, links to browse products, contact support
 *
 *  sendLowStockAlert(adminEmail, products)
 *    - Subject: 'Low Stock Alert - Action Required'
 *    - Content: table of low-stock products with current stock levels
 *
 * TIPS:
 *  - Wrap ALL email sends in try/catch — email failure should never crash the app
 *  - Queue emails via email.job.js (Bull) instead of sending synchronously in controllers
 *  - Test emails using Mailtrap (configured in .env.example)
 *  - Inline CSS in HTML emails for compatibility (most email clients strip <style> tags)
 */
