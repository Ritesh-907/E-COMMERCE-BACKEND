/**
 * validators/product.validator.js — Product Validation Schemas
 * =============================================================
 * PURPOSE: Validate product create/update request bodies.
 *
 * SCHEMAS TO EXPORT:
 *
 *  createProductSchema
 *    name:         Joi.string().min(3).max(200).trim().required()
 *    description:  Joi.string().min(20).max(5000).required()
 *    shortDesc:    Joi.string().max(200).optional()
 *    price:        Joi.number().positive().precision(2).required()
 *    comparePrice: Joi.number().positive().precision(2).greater(Joi.ref('price')).optional()
 *    category:     Joi.string().hex().length(24).required()  // ObjectId
 *    stock:        Joi.number().integer().min(0).required()
 *    sku:          Joi.string().max(50).optional()
 *    brand:        Joi.string().max(100).optional()
 *    tags:         Joi.array().items(Joi.string().max(30)).max(10).optional()
 *    isFeatured:   Joi.boolean().optional()
 *    isPublished:  Joi.boolean().optional()
 *    attributes:   Joi.object().optional()  // flexible key-value map
 *    removeImages: Joi.array().items(Joi.string()).optional()  // for updates
 *
 *  updateProductSchema
 *    Same as above but ALL fields optional (Joi.object() with no required)
 *    Use .fork(Object.keys(createProductSchema.describe().keys), (schema) => schema.optional())
 *
 * TIPS:
 *  - comparePrice must be greater than price (use Joi.ref)
 *  - ObjectId validation: Joi.string().hex().length(24)
 *  - Images come as req.files (multipart) — not validated by Joi, validate in controller/middleware
 */
