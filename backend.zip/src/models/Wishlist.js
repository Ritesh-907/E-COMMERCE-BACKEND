/**
 * models/Wishlist.js — Wishlist Schema & Model
 * ===============================================
 * PURPOSE: Store products a user has saved for later.
 *
 * FIELDS TO INCLUDE:
 *  - user     : ObjectId ref 'User', required, unique
 *  - products : [{ type: ObjectId, ref: 'Product' }]
 *  - timestamps: true
 *
 * TIPS:
 *  - Use $addToSet when adding (prevents duplicates automatically)
 *  - Use $pull when removing by productId
 *  - On populate: select only 'name price images stock isPublished ratings'
 *  - Add a virtual 'count': return this.products.length
 *  - Optionally cap at 100 items: pre('save') check products.length <= 100
 */
