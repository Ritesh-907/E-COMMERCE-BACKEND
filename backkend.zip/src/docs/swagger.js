'use strict';

/**
 * docs/swagger.js — Swagger / OpenAPI Documentation Setup
 * ==========================================================
 * PURPOSE: Serve interactive API documentation at /api/v1/docs (development only).
 *
 * How it works:
 *  1. swagger-jsdoc scans route & model files for `@swagger` JSDoc blocks and
 *     builds an OpenAPI spec from them.
 *  2. docs/openapi.yaml is loaded (if present) and deep-merged on top — it
 *     covers info/servers/components/schemas and any hand-written paths that
 *     haven't been annotated with `@swagger` comments yet.
 *  3. swagger-ui-express serves the merged spec at /api/v1/docs, and the raw
 *     JSON is available at /api/v1/docs.json.
 *
 * Safety:
 *  - Only mounted when NODE_ENV !== 'production' (never expose API structure
 *    in production).
 *  - Every step is wrapped in try/catch — a missing/invalid openapi.yaml or
 *    a swagger-jsdoc failure must NEVER crash the app. We simply skip docs
 *    and log a warning.
 */

const path = require('path');
const fs   = require('fs');

const logger = require('../utils/logger');

// ── swaggerDefinition ─────────────────────────────────────────────────────────
// Base metadata. Anything discovered by swagger-jsdoc (from @swagger comments)
// or loaded from openapi.yaml is merged on top of this.

const swaggerDefinition = {
  openapi: '3.0.0',
  info: {
    title:       'Ecommerce API',
    version:     process.env.npm_package_version || '1.0.0',
    description: 'Production-ready ecommerce REST API',
  },
  servers: [
    {
      url:         '/api/v1',
      description: 'API Server',
    },
  ],
  components: {
    securitySchemes: {
      bearerAuth: {
        type:         'http',
        scheme:       'bearer',
        bearerFormat: 'JWT',
      },
    },
  },
  security: [{ bearerAuth: [] }],
};

// ── deepMerge ──────────────────────────────────────────────────────────────────
// Recursively merges `source` into `target`. Plain objects are merged key by
// key; arrays and primitives in `source` overwrite the value in `target`.
// Used to layer openapi.yaml content on top of the swagger-jsdoc output
// without losing either side's data.

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function deepMerge(target, source) {
  const output = { ...target };

  for (const [key, value] of Object.entries(source || {})) {
    if (isPlainObject(value) && isPlainObject(output[key])) {
      output[key] = deepMerge(output[key], value);
    } else {
      output[key] = value;
    }
  }

  return output;
}

// ── buildSwaggerSpec ──────────────────────────────────────────────────────────

/**
 * Build the merged OpenAPI spec.
 * Never throws — returns the base swaggerDefinition if anything fails.
 *
 * @returns {object} OpenAPI 3.0 spec
 */
function buildSwaggerSpec() {
  let spec = swaggerDefinition;

  // ── 1. swagger-jsdoc — scan routes & models for @swagger annotations ───────
  try {
    const swaggerJsdoc = require('swagger-jsdoc');

    const generated = swaggerJsdoc({
      definition: swaggerDefinition,
      apis: [
        path.join(__dirname, '..', 'routes', '*.js'),
        path.join(__dirname, '..', 'models', '*.js'),
      ],
    });

    spec = deepMerge(spec, generated);
  } catch (err) {
    logger.warn('swagger-jsdoc generation failed — falling back to base spec', {
      error: err.message,
    });
  }

  // ── 2. docs/openapi.yaml — hand-written reference spec ──────────────────────
  // Layered on top so manually documented paths/schemas are always included,
  // even before the corresponding route gets a @swagger JSDoc block.
  try {
    const yamlPath = path.join(__dirname, 'openapi.yaml');

    if (fs.existsSync(yamlPath)) {
      const yaml = require('js-yaml');
      const raw  = fs.readFileSync(yamlPath, 'utf8');
      const doc  = yaml.load(raw);

      if (isPlainObject(doc)) {
        spec = deepMerge(spec, doc);
      }
    }
  } catch (err) {
    logger.warn('Failed to load docs/openapi.yaml — skipping', {
      error: err.message,
    });
  }

  return spec;
}

// ── setupSwagger ──────────────────────────────────────────────────────────────

/**
 * Mount Swagger UI and the raw OpenAPI JSON on the Express app.
 * No-op in production and a no-op (with a warning) if swagger-ui-express
 * isn't installed — never throws.
 *
 * @param {import('express').Application} app
 */
function setupSwagger(app) {
  // Never expose API structure / docs UI in production
  if (process.env.NODE_ENV === 'production') return;

  try {
    const swaggerUi = require('swagger-ui-express');
    const spec      = buildSwaggerSpec();

    app.use('/api/v1/docs', swaggerUi.serve, swaggerUi.setup(spec, {
      customSiteTitle: 'Ecommerce API Docs',
    }));

    app.get('/api/v1/docs.json', (req, res) => res.json(spec));

    logger.info('Swagger docs available at /api/v1/docs');
  } catch (err) {
    logger.warn('Swagger setup skipped — swagger-ui-express not available', {
      error: err.message,
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────

module.exports = { setupSwagger, buildSwaggerSpec };