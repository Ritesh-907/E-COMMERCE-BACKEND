/**
 * services/cache.service.js — Redis Cache Abstraction
 * =====================================================
 * PURPOSE: Simple wrapper around Redis for application-level caching.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  get(key)
 *    - try { return JSON.parse(await redisClient.get(key)) } catch { return null }
 *
 *  set(key, data, ttlSeconds)
 *    - await redisClient.setex(key, ttlSeconds, JSON.stringify(data))
 *
 *  del(key)
 *    - await redisClient.del(key)
 *
 *  flush(pattern)
 *    - Use SCAN to find all keys matching pattern (handle cursor pagination)
 *    - Delete all found keys in batches
 *    - Pattern examples: 'ec:products:*', 'cache:/api/v1/products*'
 *
 *  remember(key, ttlSeconds, fetchFn)
 *    - Cached version of a DB call:
 *        const cached = await get(key)
 *        if (cached) return cached
 *        const data = await fetchFn()
 *        await set(key, data, ttl)
 *        return data
 *    - Usage: cacheService.remember('categories', 3600, () => Category.find({ isActive: true }))
 *
 * KEY CONVENTIONS (use consistently):
 *  'cache:{route}'        → from cache middleware (e.g. 'cache:/api/v1/products?page=1')
 *  'analytics:dashboard'  → pre-computed analytics
 *  'categories:all'       → category list
 *
 * TIPS:
 *  - Graceful degrade: if Redis is down, catch errors and run fetchFn directly
 *  - Add prefix 'ec:' to all keys (configured in redis.js keyPrefix)
 *  - Never cache user-specific or sensitive data (PII)
 */
