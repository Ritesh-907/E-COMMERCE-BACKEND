/**
 * middleware/error.middleware.js — Global Error Handler
 * =======================================================
 * PURPOSE: Catch all errors and return consistent JSON error responses.
 *
 * FUNCTION: errorHandler(err, req, res, next)  ← MUST have 4 parameters
 * Mount LAST in app.js (after all routes and notFound middleware)
 *
 * IMPLEMENTATION STEPS:
 *  1. Clone error: let error = { ...err, message: err.message }
 *  2. Handle Mongoose CastError (invalid ObjectId):
 *       if (err.name === 'CastError') → AppError(`Invalid ${err.path}: ${err.value}`, 400)
 *  3. Handle Mongoose ValidationError:
 *       if (err.name === 'ValidationError')
 *         → extract all field messages, AppError(messages.join(', '), 422)
 *  4. Handle MongoDB Duplicate Key (code 11000):
 *       if (err.code === 11000)
 *         → const field = Object.keys(err.keyValue)[0]
 *         → AppError(`${field} already exists`, 400)
 *  5. Handle JWT errors:
 *       JsonWebTokenError  → AppError('Invalid token', 401)
 *       TokenExpiredError  → AppError('Token expired. Please log in again', 401)
 *  6. Handle Multer errors:
 *       MulterError LIMIT_FILE_SIZE → AppError('File too large. Max 5MB', 400)
 *  7. Log error: if (statusCode >= 500) logger.error({ message, stack, url, method })
 *  8. Send response:
 *       Development: res.status(statusCode).json({ success: false, message, stack, errors })
 *       Production:  if (isOperational) send message, else send generic 'Something went wrong'
 *
 * RESPONSE SHAPE (always):
 *  { success: false, message: string, errors?: [{ field, message }] }
 *
 * TIPS:
 *  - isOperational = true means error was intentionally thrown with AppError
 *  - Never expose stack traces or internal error details in production
 *  - Log all 500 errors for investigation
 */
