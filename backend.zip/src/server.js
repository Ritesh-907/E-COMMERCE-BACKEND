/**
 * server.js — Entry Point
 * ========================
 * PURPOSE: Boot the HTTP server, connect to DB & Redis, initialize Socket.IO.
 *
 * INSTRUCTIONS:
 *  1. Load env vars: require('dotenv').config()
 *  2. Import `app` from ./app.js
 *  3. Import `connectDB` from ./config/db.js
 *  4. Import `connectRedis` from ./config/redis.js
 *  5. Import `initSocket` from ./sockets/index.js
 *  6. Import `initCleanupJobs` from ./jobs/cleanup.job.js
 *  7. Import `initInventoryJobs` from ./jobs/inventory.job.js
 *  8. Import `initAnalyticsJobs` from ./jobs/analytics.job.js
 *  9. Create HTTP server:
 *       const http = require('http')
 *       const server = http.createServer(app)
 * 10. Initialize Socket.IO: initSocket(server)
 * 11. Connect DB and Redis, then start server:
 *       await connectDB()
 *       await connectRedis()
 *       server.listen(PORT, () => logger.info(`Server running on port ${PORT} in ${NODE_ENV} mode`))
 * 12. Start background jobs after server starts:
 *       initCleanupJobs()
 *       initInventoryJobs()
 *       initAnalyticsJobs()
 * 13. Handle process-level errors:
 *       process.on('uncaughtException', err => { logger.error(err); process.exit(1) })
 *       process.on('unhandledRejection', err => { logger.error(err); server.close(() => process.exit(1)) })
 *
 * TIPS:
 *  - Keep this file thin — no business logic here at all
 *  - Graceful shutdown: on SIGTERM → server.close() → mongoose.disconnect()
 *  - Create logs/ directory here if it doesn't exist: fs.mkdirSync('logs', { recursive: true })
 */
