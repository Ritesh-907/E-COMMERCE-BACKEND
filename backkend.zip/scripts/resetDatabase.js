'use strict';

/**
 * scripts/resetDatabase.js — Full Database Reset
 * =================================================
 * Drops all collections. DESTRUCTIVE — development/test only.
 *
 * USAGE:
 *   npm run reset-db                    → interactive confirmation prompt
 *   NODE_ENV=test npm run reset-db      → skip prompt (for CI pipelines)
 *   npm run reset-db -- --reseed        → reset then auto-run seed.js
 */

require('dotenv').config();
const readline = require('readline');
const mongoose = require('mongoose');

// ── Flags ─────────────────────────────────────────────────────────────────────
const RESEED   = process.argv.includes('--reseed');
const IS_TEST  = process.env.NODE_ENV === 'test';

// ── Collections to drop ───────────────────────────────────────────────────────
const COLLECTIONS = [
  'users',
  'products',
  'categories',
  'orders',
  'carts',
  'reviews',
  'coupons',
  'wishlists',
  'notifications',
  'refreshtokens',
];

// ── Prompt helper ─────────────────────────────────────────────────────────────

function askConfirmation(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input:  process.stdin,
      output: process.stdout,
    });
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim().toLowerCase());
    });
  });
}

// ── Reset logic ───────────────────────────────────────────────────────────────

async function resetDatabase() {
  console.log('\n⚠️  Dropping collections:');

  let dropped = 0;
  let skipped = 0;

  for (const name of COLLECTIONS) {
    try {
      await mongoose.connection.dropCollection(name);
      console.log(`   ✅ Dropped: ${name}`);
      dropped++;
    } catch (err) {
      // Collection doesn't exist — not an error
      if (err.codeName === 'NamespaceNotFound' || err.code === 26) {
        console.log(`   ⏭️  Skipped (not found): ${name}`);
        skipped++;
      } else {
        throw err;
      }
    }
  }

  console.log(`\n✅ Database reset complete. (${dropped} dropped, ${skipped} skipped)\n`);
}

// ── Entry point ───────────────────────────────────────────────────────────────

async function main() {
  // ── Safety: block production ───────────────────────────────────────────────
  if (process.env.NODE_ENV === 'production') {
    console.error('❌ Cannot reset database in production! Set NODE_ENV to development or test.');
    process.exit(1);
  }

  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error('❌ MONGO_URI is not defined in .env');
    process.exit(1);
  }

//   console.log(`\n🗄️  Target: ${uri.replace(/:\\/\\/[^@]+@/, '://***:***@')}`);
  console.log(`🌍  Environment: ${process.env.NODE_ENV || 'development'}`);

  // ── Confirmation (skip in test/CI) ─────────────────────────────────────────
  if (!IS_TEST) {
    console.log('\n⚠️  WARNING: This will permanently delete ALL data in the database.');
    const answer = await askConfirmation('Are you sure? Type "yes" to confirm: ');

    if (answer !== 'yes') {
      console.log('\nℹ️  Reset aborted.\n');
      process.exit(0);
    }
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log('\n✅ MongoDB connected');

    await resetDatabase();

    // ── Optional re-seed ────────────────────────────────────────────────────
    if (RESEED) {
      console.log('🌱 --reseed flag detected. Running seed script...\n');
      await mongoose.disconnect();
      require('./seed');
      return; // seed.js manages its own connection + exit
    }

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('❌ Reset failed:', err.message);
    await mongoose.disconnect().catch(() => {});
    process.exit(1);
  }
}

main();