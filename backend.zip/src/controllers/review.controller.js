/**
 * controllers/review.controller.js — Product Reviews
 * =====================================================
 * PURPOSE: CRUD for product reviews and ratings.
 * Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getProductReviews(req, res)
 *    - Find reviews by params.productId
 *    - Populate: user (name, avatar)
 *    - Support sort: newest (-createdAt), highest-rated (-rating), most-liked (-likesCount)
 *    - Paginate
 *    - Also aggregate rating distribution:
 *        [{ _id: '$rating', count: { $sum: 1 } }] → map to { 1: N, 2: N, ... 5: N }
 *    - Return 200: { reviews, pagination, distribution, averageRating }
 *
 *  createReview(req, res)
 *    - Check for existing review: Review.findOne({ product, user: req.user.id })
 *      → if found AppError(400, 'You have already reviewed this product')
 *    - Check verified purchase:
 *        Order.exists({ user: req.user.id, 'items.product': productId, isPaid: true })
 *        → set isVerified accordingly
 *    - If req.files: uploadService.uploadMultipleImages(files, 'ecommerce/reviews')
 *    - Review.create({ product: productId, user: req.user.id, rating, title, comment, images, isVerified })
 *    - Post-save hook auto-updates product.ratings (see Review model)
 *    - Return 201 with review
 *
 *  updateReview(req, res)
 *    - Find review by params.id, check ownership (or admin)
 *    - Handle image changes: upload new images, delete removed ones from Cloudinary
 *    - Update review fields
 *    - Save (triggers rating recalculation)
 *    - Return 200 with updated review
 *
 *  deleteReview(req, res)
 *    - Find review, check ownership or admin
 *    - Delete images from Cloudinary
 *    - review.deleteOne() (triggers post hook for rating recalculation)
 *    - Return 200: { success: true, message: 'Review deleted.' }
 *
 *  likeReview(req, res)
 *    - Toggle: if userId in review.likes → $pull, else → $addToSet
 *    - Return 200: { liked: boolean, likeCount }
 *
 * TIPS:
 *  - Use params.productId from URL (reviews nested under /products/:productId/reviews)
 *  - Aggregate rating distribution in the same query using $facet
 *  - Verified badge encourages honest reviews — check order status is 'delivered'
 */
