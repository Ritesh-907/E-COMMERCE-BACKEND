/**
 * utils/logger.js — Winston Application Logger
 * ===============================================
 * PURPOSE: Centralised logging with file and console transports.
 *
 * INSTRUCTIONS:
 *  1. Import winston
 *  2. Define log format:
 *       combine(
 *         timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
 *         errors({ stack: true }),   // Include stack trace on errors
 *         json()
 *       )
 *  3. Create logger:
 *       winston.createLogger({
 *         level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
 *         format,
 *         transports: [
 *           // Console (development only — add colorize)
 *           new winston.transports.Console({ format: combine(colorize(), simple()) }),
 *           // Error file (production)
 *           new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
 *           // Combined file (all levels)
 *           new winston.transports.File({ filename: 'logs/combined.log' })
 *         ]
 *       })
 *  4. In production: remove console transport
 *  5. Export logger
 *
 * USAGE:
 *  logger.info('Server started', { port: 5000 })
 *  logger.warn('Redis unavailable, running without cache')
 *  logger.error('DB connection failed', { error: err.message, stack: err.stack })
 *  logger.debug('Query executed', { query, duration: '12ms' })
 *
 * TIPS:
 *  - Pass objects as second arg (metadata) — winston logs them as structured JSON
 *  - Use winston-daily-rotate-file in production for automatic log rotation
 *  - Create logs/ directory at startup (server.js): fs.mkdirSync('logs', { recursive: true })
 */
