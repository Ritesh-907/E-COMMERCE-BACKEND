/**
 * events/user.events.js — User Domain Event Emitter
 * ===================================================
 * PURPOSE: Handle side-effects of user lifecycle actions.
 *
 * INSTRUCTIONS:
 *  1. Create userEmitter = new EventEmitter()
 *  2. Register listeners:
 *
 *  userEmitter.on('user.registered', async ({ user, verifyToken }) => {
 *    try {
 *      await addEmailJob('verification', user.email, { user, token: verifyToken })
 *    } catch (err) { logger.error('user.registered handler failed', { err }) }
 *  })
 *
 *  userEmitter.on('user.verified', async ({ user }) => {
 *    try {
 *      await addEmailJob('welcome', user.email, { user })
 *    } catch (err) { logger.error('user.verified handler failed', { err }) }
 *  })
 *
 *  userEmitter.on('user.loggedIn', async ({ user, ip, userAgent }) => {
 *    try {
 *      // Update lastLogin (already done in controller, but can log for audit)
 *      logger.info('AUDIT: User login', { userId: user._id, ip, userAgent })
 *    } catch (err) { logger.error('user.loggedIn handler failed', { err }) }
 *  })
 *
 *  userEmitter.on('user.passwordChanged', async ({ user }) => {
 *    try {
 *      // Optionally send security alert email
 *      // await addEmailJob('securityAlert', user.email, { user, action: 'Password changed' })
 *      logger.info('AUDIT: Password changed', { userId: user._id })
 *    } catch (err) { logger.error('user.passwordChanged handler failed', { err }) }
 *  })
 *
 *  3. module.exports = userEmitter
 *
 * USAGE (in auth.controller.js):
 *  userEmitter.emit('user.registered', { user, verifyToken: rawToken })
 *  userEmitter.emit('user.verified', { user })
 *  userEmitter.emit('user.loggedIn', { user, ip: req.ip, userAgent: req.headers['user-agent'] })
 *
 * TIPS:
 *  - Wrap each listener in try/catch — event errors must not bubble up
 *  - verifyToken is the RAW token (not hashed) — needed for the email link
 */
