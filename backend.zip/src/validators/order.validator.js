/**
 * validators/order.validator.js — Order Validation Schemas
 * ===========================================================
 * PURPOSE: Validate order creation and admin update requests.
 *
 * SCHEMAS TO EXPORT:
 *
 *  createOrderSchema
 *    items: Joi.array().items(Joi.object({
 *      product:  Joi.string().hex().length(24).required(),
 *      quantity: Joi.number().integer().min(1).max(100).required()
 *    })).min(1).required()
 *    shippingAddress: Joi.object({
 *      street:  Joi.string().required(),
 *      city:    Joi.string().required(),
 *      state:   Joi.string().required(),
 *      zip:     Joi.string().required(),
 *      country: Joi.string().required(),
 *      phone:   Joi.string().required()
 *    }).required()
 *    paymentMethod: Joi.string().valid('card', 'cod', 'wallet').required()
 *    couponCode:    Joi.string().uppercase().optional()
 *    notes:         Joi.string().max(500).optional()
 *
 *  updateOrderStatusSchema
 *    orderStatus: Joi.string().valid('pending','processing','shipped','delivered','cancelled').required()
 *    paymentStatus: Joi.string().valid('pending','paid','failed','refunded').optional()
 *    reason:        Joi.string().max(500).optional()
 *
 *  cancelOrderSchema
 *    reason: Joi.string().max(500).optional()
 *
 * TIPS:
 *  - Validate items array has at least 1 item: .min(1)
 *  - Product IDs are ObjectIds — validate as hex strings of length 24
 */
