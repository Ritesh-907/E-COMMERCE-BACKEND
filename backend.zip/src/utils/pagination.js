/**
 * utils/pagination.js — Pagination Parameter Helpers
 * =====================================================
 * PURPOSE: Extract and validate pagination params, build pagination metadata.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getPaginationParams(query)
 *    - Extract from req.query:
 *        page  = Math.max(1, parseInt(query.page) || 1)
 *        limit = Math.min(MAX_PAGE_SIZE, Math.max(1, parseInt(query.limit) || DEFAULT_PAGE_SIZE))
 *        skip  = (page - 1) * limit
 *    - Return: { page, limit, skip }
 *    - Import DEFAULT_PAGE_SIZE and MAX_PAGE_SIZE from constants.js
 *
 *  buildPaginationMeta(total, page, limit)
 *    - totalPages  = Math.ceil(total / limit)
 *    - Return: {
 *        total,
 *        page,
 *        limit,
 *        totalPages,
 *        hasNextPage: page < totalPages,
 *        hasPrevPage: page > 1,
 *        nextPage: page < totalPages ? page + 1 : null,
 *        prevPage: page > 1 ? page - 1 : null
 *      }
 *
 * STANDARD USAGE PATTERN:
 *  const { page, limit, skip } = getPaginationParams(req.query)
 *  const [docs, total] = await Promise.all([
 *    Model.find(filter).skip(skip).limit(limit).lean(),
 *    Model.countDocuments(filter)
 *  ])
 *  const pagination = buildPaginationMeta(total, page, limit)
 *  return paginatedResponse(res, docs, pagination)
 *
 * TIPS:
 *  - Always enforce MAX_PAGE_SIZE to prevent abuse (e.g. limit=999999)
 *  - Run find() and countDocuments() in parallel with Promise.all (faster)
 *  - For very large collections, consider cursor-based pagination instead
 */
