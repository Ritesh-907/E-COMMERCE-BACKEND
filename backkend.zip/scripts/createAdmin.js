'use strict';

/**
 * scripts/createAdmin.js — First Admin User Creator
 * ====================================================
 * Creates the first admin account on a fresh deployment.
 * Reads credentials from environment variables — never hardcode them.
 *
 * USAGE:
 *   ADMIN_NAME="Store Admin" ADMIN_EMAIL=admin@store.com ADMIN_PASS=SecurePass123! node scripts/createAdmin.js
 *
 *   Or add to .env temporarily:
 *     ADMIN_NAME=Admin
 *     ADMIN_EMAIL=admin@yourstore.com
 *     ADMIN_PASS=YourSecurePassword123!
 *   Then: npm run create-admin
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User     = require('../src/models/User');

// ── Validate required env vars ────────────────────────────────────────────────

const ADMIN_NAME  = process.env.ADMIN_NAME  || 'Admin';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const ADMIN_PASS  = process.env.ADMIN_PASS;

if (!ADMIN_EMAIL || !ADMIN_PASS) {
  console.error('❌ Missing required environment variables.');
  console.error('   Set ADMIN_EMAIL and ADMIN_PASS before running this script.\n');
  console.error('   Example:');
  console.error('   ADMIN_EMAIL=admin@store.com ADMIN_PASS=SecurePass123! node scripts/createAdmin.js\n');
  process.exit(1);
}

// Basic password strength check
if (ADMIN_PASS.length < 8) {
  console.error('❌ ADMIN_PASS must be at least 8 characters.');
  process.exit(1);
}

// Mask email for safe logging (admin@store.com → a***@store.com)
function maskEmail(email) {
  const [local, domain] = email.split('@');
  return `${local[0]}***@${domain}`;
}

// ── Entry point ───────────────────────────────────────────────────────────────

async function main() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error('❌ MONGO_URI is not defined in .env');
    process.exit(1);
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log('✅ MongoDB connected\n');

    // ── Check if an admin already exists ────────────────────────────────────
    const existing = await User.findOne({ role: 'admin' }).select('email');
    if (existing) {
      console.log(`ℹ️  An admin account already exists: ${maskEmail(existing.email)}`);
      console.log('   To create another admin, update the existing user\'s role in the database.\n');
      await mongoose.disconnect();
      process.exit(0);
    }

    // ── Check if email is already taken ──────────────────────────────────────
    const emailTaken = await User.findOne({ email: ADMIN_EMAIL.toLowerCase() }).select('_id role');
    if (emailTaken) {
      console.error(`❌ Email "${maskEmail(ADMIN_EMAIL)}" is already registered as a "${emailTaken.role}".`);
      console.error('   Use a different email or update the existing account\'s role.\n');
      await mongoose.disconnect();
      process.exit(1);
    }

    // ── Create admin user ────────────────────────────────────────────────────
    // User.create() triggers the pre-save hook which hashes the password
    const admin = await User.create({
      name:       ADMIN_NAME,
      email:      ADMIN_EMAIL.toLowerCase(),
      password:   ADMIN_PASS,
      role:       'admin',
      isVerified: true,
      isActive:   true,
    });

    console.log('────────────────────────────────────────');
    console.log('✅ Admin account created successfully!\n');
    console.log(`   Name  : ${admin.name}`);
    console.log(`   Email : ${maskEmail(admin.email)}`);
    console.log(`   Role  : ${admin.role}`);
    console.log(`   ID    : ${admin._id}`);
    console.log('────────────────────────────────────────');
    console.log('\n⚠️  Remove ADMIN_EMAIL and ADMIN_PASS from your .env file now.\n');

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    // Handle Mongoose validation errors clearly
    if (err.name === 'ValidationError') {
      console.error('❌ Validation error:');
      Object.values(err.errors).forEach((e) => console.error(`   • ${e.message}`));
    } else {
      console.error('❌ Failed to create admin:', err.message);
    }
    await mongoose.disconnect().catch(() => {});
    process.exit(1);
  }
}

main();