/**
 * config/rateLimit.js — Rate Limiting Middleware
 * ================================================
 * PURPOSE: Protect against brute-force and abuse.
 *
 * INSTRUCTIONS:
 *  1. Import rateLimit from 'express-rate-limit'
 *  2. Export generalLimiter (applied to all /api routes):
 *       windowMs: 15 * 60 * 1000,   // 15 minutes
 *       max: 100,
 *       standardHeaders: true,
 *       legacyHeaders: false,
 *       message: { success: false, message: 'Too many requests, please try again later.' },
 *       skip: () => process.env.NODE_ENV === 'test'
 *  3. Export authLimiter (stricter, for /auth routes):
 *       windowMs: 15 * 60 * 1000,
 *       max: 10,
 *       message: { success: false, message: 'Too many attempts, please try again in 15 minutes.' }
 *  4. Export uploadLimiter (for upload routes):
 *       windowMs: 60 * 60 * 1000,   // 1 hour
 *       max: 20
 *
 * TIPS:
 *  - In production, use a Redis store: new RedisStore({ sendCommand: (...args) => redisClient.call(...args) })
 *  - Add keyGenerator: (req) => req.ip to rate limit by IP
 *  - Apply authLimiter in auth.routes.js on login + forgot-password
 */
