/**
 * controllers/payment.controller.js — Stripe Payment Handling
 * =============================================================
 * PURPOSE: Create payment intents and handle Stripe webhooks.
 * Wrap non-webhook functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  createPaymentIntent(req, res)
 *    - req.body: { orderId }
 *    - Fetch order: Order.findOne({ _id: orderId, user: req.user.id })
 *    - If not found or already paid → AppError
 *    - ALWAYS use order.totalPrice from DB (never trust client-sent amount)
 *    - paymentService.createPaymentIntent(order.totalPrice, 'usd', { orderId, userId: req.user.id })
 *    - Return 200: { success: true, clientSecret }
 *
 *  handleWebhook(req, res)
 *    !! USE express.raw() ON THIS ROUTE — NOT express.json() !!
 *    !! This route must be mounted BEFORE json body parser in app.js !!
 *    - Get signature: req.headers['stripe-signature']
 *    - Verify event: paymentService.constructWebhookEvent(req.body, signature, webhookSecret)
 *    - Handle events:
 *        'payment_intent.succeeded':
 *          → orderId from event.data.object.metadata.orderId
 *          → Order.findByIdAndUpdate(orderId, { isPaid: true, paidAt: now, paymentStatus: 'paid',
 *               paymentResult: { id, status, update_time, email_address } })
 *          → emit 'order.paid' event
 *        'payment_intent.payment_failed':
 *          → Update order paymentStatus = 'failed'
 *        'charge.refunded':
 *          → Update order paymentStatus = 'refunded'
 *    - Always respond with 200 IMMEDIATELY (Stripe needs fast response)
 *    - Log all webhook events
 *
 *  refundPayment(req, res)  [admin only]
 *    - Find order by params.orderId
 *    - If not paid → AppError(400, 'Order has not been paid')
 *    - paymentService.refundPayment(order.paymentResult.id, req.body.amount?)
 *    - Update order.paymentStatus = 'refunded'
 *    - Return 200 with refund confirmation
 *
 * CRITICAL TIPS:
 *  !! Never trust amount from client — always calculate from DB order !!
 *  !! Webhook must use raw body for signature verification !!
 *  - Use idempotency keys on Stripe calls to prevent duplicate charges
 *  - Log webhook events to a separate log file for debugging
 *  - Webhook handler must return 200 even if your DB update fails (retry logic)
 */
