/**
 * validators/auth.validator.js — Auth Request Validation Schemas
 * ================================================================
 * PURPOSE: Joi schemas to validate auth-related request bodies.
 *
 * SCHEMAS TO EXPORT:
 *
 *  registerSchema
 *    name:            Joi.string().min(2).max(50).trim().required()
 *    email:           Joi.string().email({ tlds: { allow: false } }).lowercase().trim().required()
 *    password:        Joi.string().min(8).max(128)
 *                       .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
 *                       .required()
 *                       .messages({ 'string.pattern.base': 'Password must contain uppercase, lowercase, and a number' })
 *    confirmPassword: Joi.string().valid(Joi.ref('password')).required()
 *                       .messages({ 'any.only': 'Passwords do not match' })
 *
 *  loginSchema
 *    email:    Joi.string().email().lowercase().required()
 *    password: Joi.string().required()
 *
 *  forgotPasswordSchema
 *    email: Joi.string().email().lowercase().required()
 *
 *  resetPasswordSchema
 *    password:        Joi.string().min(8).max(128).pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).required()
 *    confirmPassword: Joi.string().valid(Joi.ref('password')).required()
 *
 *  updatePasswordSchema (for logged-in users)
 *    currentPassword: Joi.string().required()
 *    newPassword:     Joi.string().min(8).max(128).pattern(...).required()
 *    confirmPassword: Joi.string().valid(Joi.ref('newPassword')).required()
 *
 * TIPS:
 *  - .trim() on string fields removes leading/trailing whitespace
 *  - .lowercase() normalizes email before any DB query
 *  - Set options globally: Joi.object().options({ abortEarly: false })
 *  - Custom messages: .messages({ 'string.min': '{{#label}} must be at least {{#limit}} chars' })
 */
