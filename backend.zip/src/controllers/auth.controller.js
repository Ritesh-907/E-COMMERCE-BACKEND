/**
 * controllers/auth.controller.js — Authentication Controller
 * ============================================================
 * PURPOSE: Handle register, login, token refresh, logout, OAuth, and password flows.
 * Wrap all functions with asyncHandler from utils/asyncHandler.js.
 *
 * HELPER TO WRITE FIRST:
 *  sendTokenResponse(user, statusCode, res)
 *    - Generate token pair: { accessToken, refreshToken } via auth.service.generateTokenPair()
 *    - Set refreshToken as httpOnly cookie:
 *        res.cookie('refreshToken', refreshToken, {
 *          httpOnly: true, secure: NODE_ENV === 'production',
 *          sameSite: 'strict', maxAge: 7 * 24 * 60 * 60 * 1000
 *        })
 *    - Return: res.status(statusCode).json({ success: true, accessToken, user: safeUser })
 *    - safeUser = omit password, tokens, reset fields from user object
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  register(req, res)
 *    - Check User.findOne({ email }) → if exists throw AppError(400, 'Email already registered')
 *    - Create user: User.create({ name, email, password })
 *    - Generate email verify token: user.getEmailVerifyToken()
 *    - Save user (with token)
 *    - Send verification email: emailService.sendVerificationEmail(user, rawToken)
 *    - Emit 'user.registered' event
 *    - Return 201: { success: true, message: 'Registration successful. Please verify your email.' }
 *
 *  login(req, res)
 *    - Find user: User.findOne({ email }).select('+password')
 *    - If not found or password wrong → AppError(401, 'Invalid email or password')
 *    - If !user.isActive → AppError(403, 'Account deactivated. Contact support.')
 *    - If !user.isVerified → AppError(403, 'Please verify your email first.')
 *    - Update user.lastLogin = Date.now(), save
 *    - Emit 'user.loggedIn' event
 *    - Call sendTokenResponse(user, 200, res)
 *
 *  refreshToken(req, res)
 *    - Get token from req.cookies.refreshToken → if missing AppError(401)
 *    - Verify token: verifyRefreshToken(token) → decoded
 *    - Hash token, find in DB: RefreshToken.findOne({ token: hash, isRevoked: false })
 *    - Check expiresAt > now → if expired AppError(401)
 *    - Rotate: revoke old, generate new access token (optionally new refresh too)
 *    - Return new accessToken
 *
 *  logout(req, res)
 *    - Get refreshToken from cookie
 *    - If exists: hash it, set isRevoked: true in DB
 *    - Clear cookie: res.clearCookie('refreshToken')
 *    - Return 200: { success: true, message: 'Logged out successfully' }
 *
 *  forgotPassword(req, res)
 *    - Find user by email (don't reveal if not found — same response either way)
 *    - If user exists: user.getPasswordResetToken(), save user
 *    - Send reset email: emailService.sendPasswordResetEmail(user, rawToken)
 *    - Return 200: { success: true, message: 'Password reset email sent.' }
 *
 *  resetPassword(req, res)
 *    - Hash token from req.params.token
 *    - Find user: { passwordResetToken: hash, passwordResetExpire: { $gt: Date.now() } }
 *    - If not found → AppError(400, 'Invalid or expired token')
 *    - Set user.password = req.body.password
 *    - Clear reset fields: passwordResetToken = undefined, passwordResetExpire = undefined
 *    - Revoke all refresh tokens: authService.revokeAllUserTokens(user._id)
 *    - Save user (pre-save hook hashes password)
 *    - Emit 'user.passwordChanged' event
 *    - Return 200 or call sendTokenResponse to auto-login
 *
 *  verifyEmail(req, res)
 *    - Hash token from req.params.token
 *    - Find user: { emailVerifyToken: hash, emailVerifyExpire: { $gt: Date.now() } }
 *    - If not found → AppError(400, 'Invalid or expired verification link')
 *    - Set user.isVerified = true, clear verify fields
 *    - Save user
 *    - Emit 'user.verified' event
 *    - Return 200: { success: true, message: 'Email verified successfully.' }
 *
 *  googleCallback(req, res)
 *    - req.user is set by Passport GoogleStrategy
 *    - Call sendTokenResponse(req.user, 200, res) OR
 *    - Redirect: res.redirect(`${CLIENT_URL}/auth/success?token=${accessToken}`)
 *
 * TIPS:
 *  - Use SAME error message for "email not found" and "wrong password" (prevents enumeration)
 *  - Log failed login attempts (ip, email, timestamp) for security audit
 *  - Always call next(err) not throw, OR use asyncHandler
 */
