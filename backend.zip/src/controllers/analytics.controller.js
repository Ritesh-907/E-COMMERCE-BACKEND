/**
 * controllers/analytics.controller.js — Admin Analytics Dashboard
 * =================================================================
 * PURPOSE: Revenue, order, user, and product analytics for admin dashboard.
 * All routes: admin only. Wrap all functions with asyncHandler.
 *
 * FUNCTIONS TO IMPLEMENT:
 *
 *  getDashboardStats(req, res)
 *    - Use analyticsService.getDashboardStats() (which caches the result)
 *    - Returns:
 *        totalRevenue      : sum of all paid order totals
 *        revenueToday      : sum of paid orders today
 *        orderCounts       : { total, pending, processing, shipped, delivered, cancelled }
 *        newUsers          : { today, thisWeek, thisMonth }
 *        lowStockProducts  : products where stock < LOW_STOCK_THRESHOLD (count + list)
 *        topProduct        : best-selling product this month
 *    - Cache with 5-minute TTL
 *    - Return 200 with stats
 *
 *  getRevenueChart(req, res)
 *    - Query params: period ('daily'|'weekly'|'monthly'), from (date), to (date)
 *    - analyticsService.getRevenueByPeriod(from, to, period)
 *    - Returns array: [{ date: '2024-01-01', revenue: 1500, orderCount: 12 }]
 *    - Return 200 with chart data
 *
 *  getTopProducts(req, res)
 *    - analyticsService.getTopSellingProducts(limit = 10)
 *    - Returns: [{ product, sold, revenue }]
 *    - Return 200 with top products
 *
 *  getTopCategories(req, res)
 *    - Aggregate orders → unwind items → lookup product.category → group by category → sum revenue
 *    - Return 200 with category revenue breakdown
 *
 *  getUserGrowth(req, res)
 *    - analyticsService.getUserStats() grouped by date
 *    - Return 200 with growth data for charts
 *
 * TIPS:
 *  - Cache ALL analytics responses (5-15 min TTL) — these are expensive queries
 *  - Use MongoDB $facet to run multiple aggregations in one round-trip
 *  - Analytics pre-computation job (analytics.job.js) can refresh cache hourly
 *  - All aggregations should match only paid orders (isPaid: true)
 */
