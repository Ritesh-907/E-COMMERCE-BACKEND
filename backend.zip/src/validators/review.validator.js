/**
 * validators/review.validator.js — Review Validation Schemas
 * ===========================================================
 * PURPOSE: Validate review create/update request bodies.
 *
 * SCHEMAS TO EXPORT:
 *
 *  createReviewSchema
 *    rating:  Joi.number().integer().min(1).max(5).required()
 *    title:   Joi.string().min(3).max(100).trim().optional()
 *    comment: Joi.string().min(10).max(1000).trim().required()
 *    NOTE: product comes from req.params.productId (not body)
 *          images come from req.files (multipart — not validated by Joi)
 *
 *  updateReviewSchema
 *    rating:      Joi.number().integer().min(1).max(5).optional()
 *    title:       Joi.string().min(3).max(100).trim().optional()
 *    comment:     Joi.string().min(10).max(1000).trim().optional()
 *    removeImages:Joi.array().items(Joi.string()).optional()
 *
 * TIPS:
 *  - Comment min length of 10 ensures meaningful reviews
 *  - Images are validated separately (file type/size) by upload.middleware.js
 *  - productId validation (ObjectId) should be done in params, not body
 */
