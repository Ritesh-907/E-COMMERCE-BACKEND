/**
 * sockets/chat.socket.js — Live Customer Support Chat
 * ======================================================
 * PURPOSE: Real-time chat between customers and admin support agents.
 *
 * EXPORT: chatSocketHandler(io, socket)
 *
 * IMPLEMENTATION:
 *  module.exports = function chatSocketHandler(io, socket) {
 *
 *    // Join a chat room (identified by orderId or support ticket ID)
 *    socket.on('chat:join', ({ roomId }) => {
 *      // Validate: user should only join their own order's chat (or admin joins any)
 *      socket.join(`chat:${roomId}`)
 *      socket.emit('chat:joined', { roomId })
 *      logger.debug('User joined chat room', { userId: socket.userId, roomId })
 *    })
 *
 *    // Send a message
 *    socket.on('chat:message', async ({ roomId, message }) => {
 *      try {
 *        if (!message || message.trim().length === 0) return
 *        if (message.length > 1000) return socket.emit('chat:error', { message: 'Message too long' })
 *        const msgData = {
 *          roomId,
 *          senderId:   socket.userId,
 *          senderRole: socket.userRole,
 *          message:    message.trim(),
 *          timestamp:  new Date().toISOString()
 *        }
 *        // Optionally save to DB: ChatMessage.create(msgData)
 *        // Broadcast to everyone in the room
 *        io.to(`chat:${roomId}`).emit('chat:message', msgData)
 *      } catch (err) { socket.emit('chat:error', { message: 'Failed to send message' }) }
 *    })
 *
 *    // Typing indicator
 *    socket.on('chat:typing', ({ roomId, isTyping }) => {
 *      socket.to(`chat:${roomId}`).emit('chat:typing', { userId: socket.userId, isTyping })
 *    })
 *
 *    // Leave room
 *    socket.on('chat:leave', ({ roomId }) => {
 *      socket.leave(`chat:${roomId}`)
 *    })
 *  }
 *
 * TIPS:
 *  - roomId = orderId is a clean pattern (one chat per order)
 *  - For full history: create a ChatMessage model and save messages on 'chat:message'
 *  - Emit 'chat:history' on join with last N messages from DB
 *  - Admin can join any room; customers only their own (validate in chat:join handler)
 */
